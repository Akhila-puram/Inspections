// import React, { useContext, useEffect, useRef, useState } from "react";
// import {
//     Box,
//     Typography,
//     Grid2,
//     Button,
//     useTheme,
//     Divider,
//     styled,
//     TextField,
//     IconButton,
//     CircularProgress,
//     FormControlLabel,
//     RadioGroup,
//     Link,
//     Checkbox,
//     FormControl,
//     Select,
//     MenuItem,
// } from "@mui/material";
// import ArrowRightIcon from "@mui/icons-material/ArrowRight";
// import CustomCheckbox from "../global/CustomCheckbox";
// import AttachFileIcon from "@mui/icons-material/AttachFile";
// import AddActionsOutlinedIcon from "@mui/icons-material/PlaylistAddOutlined";
// import AddNotes from "../../assets/add-notes.png";
// import DownloadImage from "../../assets/download.png";
// import CheckIcon from "@mui/icons-material/Check";
// import CloseIcon from "@mui/icons-material/Close";
// import "./checklist.css";
// import axios from "axios";
// import { SnackContext } from "../global/SnackProvider";
// import { useNavigate } from "react-router-dom";
// import CustomRadio from "../global/CustomRadio";
// import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
// import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
// import AddIcon from "@mui/icons-material/Add";
// import dayjs from "dayjs";
// import Loader from "../global/Loader";
// import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
// import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";

// const Checklist = ({
//     inspectionChecklists,
//     inspectionID,
//     inspectorReport,
//     approverReport,
//     action = "",
//     groupInspectors = [],
//     caseDetails,
// }) => {
//     const theme = useTheme();
//     const navigate = useNavigate();
//     const [inspectionChecklist, setInspectionChecklist] = useState([]);
//     const [categoryChecklist, setCategoryChecklist] = useState({});
//     const [categoryChecklistItems, setCategoryChecklistItems] = useState([]);
//     const [categoryName, setCategoryName] = useState("");
//     const [correctiveAction, setCorrectiveAction] = useState("");
//     const [displayNote, setDisplayNote] = useState("");
//     const [displayAddAction, setDisplayAddAction] = useState("");
//     const currentChecklistId = useRef(0);
//     const [inspectionReport, setInspectionReport] = useState("");
//     const [showInspectionReport, setShowInspectionReport] = useState(
//         localStorage.getItem("userRole") === "INSPECTOR" ? false : true
//     );
//     const [showRecommendedActions, setShowRecommendedActions] = useState(false);
//     const totalChecklistItems = useRef(0);
//     const answeredChecklistItems = useRef(0);
//     const checklistContainerRef = useRef(null);
//     const { snack, setSnack } = useContext(SnackContext);
//     const [isSaveInspection, setIsSaveInspection] = useState(false);
//     const [approverCategoryReport, setApproverCategoryReport] = useState("");
//     const [reviwerCategoryReport, setReviwerCategoryReport] = useState("");
//     const [recommendedAction, setRecommendedAction] = useState(null);
//     const [inspectionSummaryReport, setInspectionSummaryReport] = useState("");
//     const [inspectionDate, setInspectionDate] = useState(null);
//     const [followUpDate, setFollowUpDate] = useState(null);
//     const [ReInspectionDate, setReInspectionDate] = useState(null);
//     const [selectedchecklistitems, setSelectedChecklistItems] = useState([]);
//     const [apiData, setApiData] = useState("");
//     const categoryRefs = useRef([]);
//     const [isRedo, setIsRedo] = useState(false);
//     const [inputs, setInputs] = useState({});
//     const [selectedItems, setSelectedItems] = useState([]);
//     const [isEditCorrectiveAction, setIsEditCorrectiveAction] = useState(false);
//     const [editedCorrectiveAction, setEditedCorrectiveAction] = useState("");
//     const answeredChecklistCount = useRef({});
//     const [correctiveActionId, setCorrectiveActionId] = useState(null);
//     const [categoryInspectorID, setCategoryInspectorID] = useState("");

//     const VisuallyHiddenInput = styled("input")`
//         clip: rect(0 0 0 0);
//         clip-path: inset(50%);
//         height: 1px;
//         overflow: hidden;
//         position: absolute;
//         bottom: 0;
//         left: 0;
//         white-space: nowrap;
//         width: 1px;
//     `;

//     useEffect(() => {
//         if (checklistContainerRef.current) {
//             checklistContainerRef.current.scrollTop = 0;
//         }
//     }, [inspectionChecklist[currentChecklistId.current]]);

//     useEffect(() => {
//         setInspectionChecklist(inspectionChecklists);
//     }, [inspectionChecklists]);

//     useEffect(() => {
//         setInspectionReport(inspectorReport);
//     }, [inspectorReport]);

//     useEffect(() => {
//         setInspectionSummaryReport(approverReport);
//     }, [approverReport]);

//     useEffect(() => {
//         inspectionChecklists?.map((checklist) => {
//             totalChecklistItems.current += checklist?.checklistItem?.length;
//         });
//         setCategoryChecklist(inspectionChecklists[0]);
//         setCategoryChecklistItems(inspectionChecklists[0]?.checklistItem);
//         setCategoryName(inspectionChecklists[0]?.categoryName);
//         setCategoryInspectorID(inspectionChecklists[0]?.inspectorID);
//     }, [inspectionChecklists]);

//     useEffect(() => {
//         setSelectedChecklistItems([]);
//     }, [categoryChecklist]);

//     const updateInspectionChecklist = () => {
//         if (categoryChecklistItems.length > 0) {
//             setInspectionChecklist((prevItems) => {
//                 return prevItems.map((item) => {
//                     if (item?.categoryName === categoryName) {
//                         return {
//                             ...item,
//                             checklistItem: categoryChecklistItems,
//                             approverComment: approverCategoryReport,
//                             reviewerComment: reviwerCategoryReport,
//                         };
//                     }
//                     return item;
//                 });
//             });
//         }
//         // setApproverCategoryReport('')
//         setShowInspectionReport(false);
//         setShowRecommendedActions(false);
//         setCategoryChecklist(inspectionChecklist[currentChecklistId.current]);
//         setCategoryChecklistItems(inspectionChecklist[currentChecklistId.current]?.checklistItem);
//         setCategoryName(inspectionChecklist[currentChecklistId.current]?.categoryName);
//         setCategoryInspectorID(inspectionChecklist[currentChecklistId.current]?.inspectorID);
//         setApproverCategoryReport(
//             inspectionChecklist[currentChecklistId.current]?.approverComment
//                 ? inspectionChecklist[currentChecklistId.current]?.approverComment
//                 : ""
//         );
//         setReviwerCategoryReport(
//             inspectionChecklist[currentChecklistId.current]?.reviewerComment
//                 ? inspectionChecklist[currentChecklistId.current]?.reviewerComment
//                 : ""
//         );
//         setDisplayNote("");
//         setDisplayAddAction("");
//         if (categoryRefs.current[currentChecklistId.current]) {
//             categoryRefs.current[currentChecklistId.current].focus(); // Focus on the clicked category
//         }
//     };

//     const updateCategoryInspector = (inspectorId) => {
//         setCategoryInspectorID(inspectorId);
//         setInspectionChecklist((prevItems) => {
//             return prevItems.map((item) => {
//                 if (item?.categoryName === categoryName) {
//                     return {
//                         ...item,
//                         inspectorID: inspectorId,
//                     };
//                 }
//                 return item;
//             });
//         });
//     };

//     const displayInspectionReport = () => {
//         setInspectionChecklist((prevItems) => {
//             return prevItems.map((item) => {
//                 if (item?.categoryName === categoryName) {
//                     return {
//                         ...item,
//                         checklistItem: categoryChecklistItems,
//                     };
//                 }
//                 return item;
//             });
//         });
//         setCategoryChecklist({});
//         setCategoryChecklistItems([]);
//         setCategoryName("");
//         setCategoryInspectorID("");
//         setDisplayNote("");
//         setDisplayAddAction("");
//         setShowInspectionReport(true);
//         setShowRecommendedActions(false);
//     };

//     const displayRecommendedActions = () => {
//         setInspectionChecklist((prevItems) => {
//             return prevItems.map((item) => {
//                 if (item?.categoryName === categoryName) {
//                     return {
//                         ...item,
//                         checklistItem: categoryChecklistItems,
//                         approverComment: approverCategoryReport,
//                         reviewerComment: reviwerCategoryReport,
//                     };
//                 }
//                 return item;
//             });
//         });
//         setShowRecommendedActions(true);
//         setShowInspectionReport(false);
//     };

//     const attchImage = async (e, checklist) => {
//         const response = await getBase64(e);
//         setCategoryChecklistItems((prevItems) => {
//             return prevItems.map((item) => {
//                 if (item.checklist_name === checklist.checklist_name) {
//                     return {
//                         ...item,
//                         attachments:
//                             item.attachments?.length > 0 ? [...item.attachments, e.target.files[0]] : [e.target.files[0]],
//                         attachmentsBase64:
//                             item.attachmentsBase64?.length > 0 ? [...item.attachmentsBase64, response] : [response],
//                     };
//                 }
//                 return item;
//             });
//         });
//     };

//     const getBase64 = async (e) => {
//         return new Promise((resolve, reject) => {
//             const file = e.target.files[0];
//             if (file) {
//                 const reader = new FileReader();
//                 reader.onloadend = () => {
//                     const base64String = reader.result.replace("data:", "").replace(/^.+,/, "");
//                     resolve(base64String);
//                 };
//                 reader.onerror = (error) => reject(error);
//                 reader.readAsDataURL(file);
//             } else {
//                 reject("No file selected");
//             }
//         });
//     };

//     const updateChecklistNote = (e, checklist) => {
//         setCategoryChecklistItems((prevItems) => {
//             return prevItems.map((item) => {
//                 if (item.checklist_name === checklist.checklist_name) {
//                     return {
//                         ...item,
//                         comment: e.target.value,
//                     };
//                 }
//                 return item;
//             });
//         });
//     };

//     const updateCorrectiveActions = (checklist) => {
//         setCategoryChecklistItems((prevItems) => {
//             return prevItems.map((item) => {
//                 if (item.checklist_name === checklist.checklist_name) {
//                     return {
//                         ...item,
//                         selected_corrective_action:
//                             item.selected_corrective_action?.length > 0
//                                 ? [...item.selected_corrective_action, correctiveAction]
//                                 : [correctiveAction],
//                     };
//                 }
//                 return item;
//             });
//         });
//         setDisplayAddAction("");
//         setCorrectiveAction("");
//     };

//     const editCorrectiveAction = (checklist, action) => {
//         setCategoryChecklistItems((prevItems) => {
//             return prevItems.map((item) => {
//                 if (item.checklist_name === checklist.checklist_name) {
//                     return {
//                         ...item,
//                         selected_corrective_action: item.selected_corrective_action?.map((correctiveAction) =>
//                             correctiveAction === action ? editedCorrectiveAction : correctiveAction
//                         ),
//                     };
//                 }
//                 return item;
//             });
//         });
//         setIsEditCorrectiveAction(false);
//         setEditedCorrectiveAction("");
//     };

//     const deleteCorrectiveAction = (checklist, action) => {
//         setCategoryChecklistItems((prevItems) => {
//             return prevItems.map((item) => {
//                 if (item.checklist_name === checklist.checklist_name) {
//                     return {
//                         ...item,
//                         selected_corrective_action: item.selected_corrective_action?.filter(
//                             (corrctiveAction) => corrctiveAction !== action
//                         ),
//                     };
//                 }
//                 return item;
//             });
//         });
//     };

//     const updateChecklistAnswer = (checklist, choice) => {
//         setCategoryChecklistItems((prevItems) => {
//             return prevItems.map((item) => {
//                 if (item.checklist_name === checklist.checklist_name) {
//                     return {
//                         ...item,
//                         selected_answer: choice,
//                     };
//                 }
//                 return item;
//             });
//         });
//         if (!answeredChecklistCount.current[categoryName]) {
//             answeredChecklistCount.current[categoryName] = [checklist?.checklist_id];
//             answeredChecklistItems.current = parseInt(answeredChecklistItems.current) + 1;
//         } else {
//             if (!answeredChecklistCount.current[categoryName].includes(checklist?.checklist_id)) {
//                 answeredChecklistCount.current[categoryName].push(checklist?.checklist_id);
//                 answeredChecklistItems.current = parseInt(answeredChecklistItems.current) + 1;
//             }
//         }
//     };

//     const getImageThumbnail = (attachment) => {
//         if (typeof attachment === "string") {
//             // Extract MIME type if present, otherwise default to 'image/png'
//             const mimeTypeMatch = attachment.match(/^data:image\/(png|jpeg|jpg|gif|webp|bmp|svg\+xml);base64,/);
//             const mimeType = mimeTypeMatch ? `image/${mimeTypeMatch[1]}` : "image/png";

//             // Remove base64 prefix if it exists
//             const base64Data = attachment.replace(/^data:image\/(png|jpeg|jpg|gif|webp|bmp|svg\+xml);base64,/, "");

//             // Convert base64 to a Blob
//             const byteCharacters = atob(base64Data);
//             const byteNumbers = new Uint8Array(byteCharacters.length);
//             for (let i = 0; i < byteCharacters.length; i++) {
//                 byteNumbers[i] = byteCharacters.charCodeAt(i);
//             }
//             const blob = new Blob([byteNumbers], { type: mimeType });

//             return URL.createObjectURL(blob);
//         }
//         const imageUrl = URL.createObjectURL(attachment);
//         return imageUrl;
//     };

//     const saveInspection = async () => {
//         try {
//             setIsSaveInspection(true);
//             let submissionData = [];
//             inspectionChecklist?.forEach((checklistCategory) => {
//                 if (checklistCategory?.categoryName === categoryName) {
//                     categoryChecklistItems?.forEach((item) => {
//                         submissionData.push({
//                             id: {
//                                 inspectionID: inspectionID,
//                                 categoryID: checklistCategory?.categoryId,
//                                 checklistID: item?.checklist_id,
//                             },
//                             selected_answer: item?.selected_answer,
//                             attachment: item?.attachmentsBase64 || null,
//                             comment: item?.comment?.trim(),
//                             corrective_actions: item?.selected_corrective_action || [],
//                         });
//                     });
//                 } else {
//                     checklistCategory?.checklistItem?.forEach((item) => {
//                         submissionData.push({
//                             id: {
//                                 inspectionID: inspectionID,
//                                 categoryID: checklistCategory?.categoryId,
//                                 checklistID: item?.checklist_id,
//                             },
//                             selected_answer: item?.selected_answer,
//                             attachment: item?.attachmentsBase64 || null,
//                             comment: item?.comment?.trim(),
//                             corrective_actions: item?.selected_corrective_action || [],
//                         });
//                     });
//                 }
//             });
//             const response = await axios({
//                 method: "post",
//                 url: `${import.meta.env.VITE_BASE_URL}/saveInspection`,
//                 data: {
//                     inspectionChecklistandAnswers: submissionData,
//                     inspectorComment: inspectionReport,
//                 },
//             });
//             if (response?.data?.status === "Failure") {
//                 setSnack({ open: true, message: "Something went wrong. Please try again.", severity: "error" });
//             } else {
//                 setSnack({ open: true, message: "Inspection saved successfully.", severity: "success" });
//             }
//             setIsSaveInspection(false);
//         } catch (error) {
//             console.log(error);
//             setIsSaveInspection(false);
//             setSnack({ open: true, message: "An error occurred while saving the inspection.", severity: "error" });
//         }
//     };

//     const submitInspection = async () => {
//         try {
//             setIsSaveInspection(true);
//             let submissionData = [];
//             inspectionChecklist?.map((checklistCategory) => {
//                 checklistCategory?.checklistItem?.map((item) => {
//                     submissionData.push({
//                         id: {
//                             inspectionID: inspectionID,
//                             categoryID: checklistCategory?.categoryId,
//                             checklistID: item?.checklist_id,
//                         },
//                         selected_answer: item?.selected_answer,
//                         attachment: item?.attachmentsBase64 || null,
//                         comment: item?.comment?.trim(),
//                         corrective_actions: item?.selected_corrective_action?.filter((action) => action !== "") || [],
//                     });
//                 });
//             });
//             const response = await axios({
//                 method: "post",
//                 url: `${import.meta.env.VITE_BASE_URL}/submitInspection/${inspectionID}`,
//                 data: {
//                     inspectionChecklistandAnswers: submissionData,
//                     inspectorComment: inspectionReport,
//                 },
//             });
//             if (response?.data?.status === "Failure") {
//                 setSnack({ open: true, message: "Something went wrong. Please try again later.", severity: "error" });
//             } else {
//                 setSnack({ open: true, message: "Inspection submitted successfully.", severity: "success" });
//                 navigate("/cases");
//             }
//             setIsSaveInspection(false);
//         } catch (error) {
//             console.log(error);
//             setIsSaveInspection(false);
//         }
//     };

//     const saveSubmitReviewerApproval = async (action, recommendedAction, dateOfFollowUp, ReInspectionDate) => {
//         try {
//             setIsSaveInspection(true);
//             const reviewReport = [];
//             inspectionChecklist?.map((checklist) => {
//                 reviewReport.push({
//                     id: {
//                         inspectionID: inspectionID,
//                         categoryID: checklist?.categoryId,
//                     },
//                     approverComment: checklist?.approverComment,
//                     reviewerComment: checklist?.reviewerComment,
//                 });
//             });

//             const userRole = localStorage.getItem("userRole");
//             let inspectionStage = "review"; // Default to review
//             if (userRole === "APPROVER") {
//                 inspectionStage = "approver";
//             } else if (userRole === "REVIEWER") {
//                 inspectionStage = "review";
//             }
//             const response = await axios({
//                 method: "post",
//                 url: `${import.meta.env.VITE_BASE_URL}/reviewInspection`,
//                 data: {
//                     inspectionId: inspectionID,
//                     inspectionStage: inspectionStage,
//                     approverReviewerComments: reviewReport,
//                     overallComment: inspectionSummaryReport,
//                     action: action,
//                     recommendedAction: recommendedAction,
//                     dateOfFollowUp: dateOfFollowUp,
//                     dateOfReinspection: ReInspectionDate,
//                 },
//             });

//             if (action === "save") {
//                 setSnack({ open: true, message: "Saved Inspection Approval.", severity: "success" });
//             }
//             if (action === "submit") {
//                 setSnack({ open: true, message: "Inspection Approved Successfully.", severity: "success" });
//                 navigate(`/cases`);
//             }

//             setIsSaveInspection(false);
//         } catch (error) {
//             setIsSaveInspection(false);
//             console.log("Error during review submission:", error);
//             setSnack({ open: true, message: "Something went wrong. Please try again later.", severity: "error" });
//         }
//     };

//     const fetchData = async (checklistId) => {
//         try {
//             setIsSaveInspection(true);
//             const response = await axios.post(`${import.meta.env.VITE_BASE_URL}/askCopilot`, {
//                 prompt: inputs[checklistId] || "",
//             });

//             if (response.data.status === "SUCCESS") {
//                 setApiData((prevApiData) => ({
//                     ...prevApiData,
//                     [checklistId]: response.data.chatGPTResponse,
//                 }));
//             } else {
//                 setApiData((prevApiData) => ({
//                     ...prevApiData,
//                     [checklistId]: "Error: Unable to fetch data",
//                 }));
//             }
//             setIsSaveInspection(false);
//         } catch (error) {
//             setIsSaveInspection(false);
//             console.error("Error fetching data from API:", error);
//             setApiData((prevApiData) => ({
//                 ...prevApiData,
//                 [checklistId]: "Error: Unable to fetch data",
//             }));
//         }
//     };

//     const handleInputChange = (event, checklistId) => {
//         setInputs((prevInputs) => ({
//             ...prevInputs,
//             [checklistId]: event.target.value,
//         }));
//     };

//     const handleSubmit = (checklistId) => {
//         fetchData(checklistId);
//     };

//     const handleClear = (checklistId) => {
//         setInputs((prevInputs) => ({
//             ...prevInputs,
//             [checklistId]: "",
//         }));
//     };

//     const handleAddToNotes = (event, checklist) => {
//         event.preventDefault();
//         setCategoryChecklistItems((prevItems) => {
//             return prevItems.map((item) => {
//                 if (item.checklist_name === checklist.checklist_name) {
//                     return {
//                         ...item,
//                         comment: apiData[checklist.checklist_id],
//                     };
//                 }
//                 return item;
//             });
//         });
//     };

//     const handleGoBackFromRedo = () => {
//         setIsRedo(true);
//         categoryRefs.current[currentChecklistId.current].click();
//     };

//     // Handle checkbox changes
//     const handleCheckboxChange = (e, checklistId) => {
//         const isChecked = e.target.checked;
//         setSelectedItems((prevSelectedItems) => {
//             if (isChecked) {
//                 return [...prevSelectedItems, checklistId];
//             } else {
//                 return prevSelectedItems.filter((id) => id !== checklistId);
//             }
//         });
//     };

//     const assignCategoriesToInspectors = async () => {
//         try {
//             let categoryInspectorMapping = [];
//             inspectionChecklist?.map((checklist) => {
//                 let obj = {
//                     assignTo: checklist?.inspectorID,
//                     checklistCatId: checklist?.categoryId,
//                 };
//                 categoryInspectorMapping.push(obj);
//             });
//             console.log(categoryInspectorMapping);
//             const response = await axios({
//                 method: "post",
//                 url: `${import.meta.env.VITE_BASE_URL}/assignCategory/${inspectionID}/Submit`,
//                 data: categoryInspectorMapping,
//             });
//             console.log(response);
//         } catch (error) {
//             console.log(error);
//         }
//     };

//     return (
//         <>
//             <Grid2 container sx={{ m: 2.5 }} spacing={2.5}>
//                 {isSaveInspection && <Loader />}
//                 <Grid2 size={3} className="categoryContainer">
//                     {(localStorage.getItem("userRole") === "REVIEWER" || localStorage.getItem("userRole") === "APPROVER") && (
//                         <Box
//                             className="inspectionReportItem"
//                             sx={{
//                                 backgroundColor: showInspectionReport ? theme.palette.colors[20] : "",
//                             }}
//                             onClick={displayInspectionReport}
//                         >
//                             <ArrowRightIcon sx={{ fontSize: 30 }} />
//                             <Typography className="typographyFontWeight">Inspection Report</Typography>
//                         </Box>
//                     )}
//                     <Box display="flex" alignItems="center" justifyContent="space-between">
//                         <Box display="flex" alignItems="center">
//                             <ArrowRightIcon sx={{ fontSize: 30 }} />
//                             <Typography className="typographyFontWeight">Categories</Typography>
//                         </Box>
//                         {localStorage.getItem("userRole") === "INSPECTOR" && (
//                             <Box display="flex" pr={2}>
//                                 <Typography className="typographyFontWeight">
//                                     {answeredChecklistItems.current}/{totalChecklistItems.current}
//                                 </Typography>
//                             </Box>
//                         )}
//                     </Box>
//                     <Box>
//                         {inspectionChecklist?.map((category, index) => {
//                             return (
//                                 <Box
//                                     className="categoryItems"
//                                     key={index}
//                                     tabIndex={0}
//                                     ref={(el) => (categoryRefs.current[index] = el)}
//                                     sx={{
//                                         backgroundColor:
//                                             !showInspectionReport &&
//                                             !showRecommendedActions &&
//                                             category?.categoryId === categoryChecklist?.categoryId
//                                                 ? theme.palette.colors[20]
//                                                 : "",
//                                     }}
//                                     onClick={() => {
//                                         currentChecklistId.current = index;
//                                         updateInspectionChecklist();
//                                     }}
//                                 >
//                                     <Typography className="typographyFontWeight">
//                                         {category.categoryName.length > 25
//                                             ? category.categoryName.slice(0, 24) + "..."
//                                             : category.categoryName}
//                                     </Typography>
//                                     {localStorage.getItem("userRole") === "INSPECTOR" && (
//                                         <Typography className="typographyFontWeight">
//                                             {answeredChecklistCount.current[category.categoryName]?.length}/
//                                             {category.checklistItem.length}
//                                         </Typography>
//                                     )}
//                                 </Box>
//                             );
//                         })}
//                     </Box>
//                     {action !== "assign" && localStorage.getItem("userRole") === "INSPECTOR" && (
//                         <Box
//                             className="inspectionReportItem"
//                             sx={{
//                                 backgroundColor: showInspectionReport ? theme.palette.colors[20] : "",
//                             }}
//                             onClick={displayInspectionReport}
//                         >
//                             <ArrowRightIcon sx={{ fontSize: 30 }} />
//                             <Typography className="typographyFontWeight">Inspection Report</Typography>
//                         </Box>
//                     )}
//                     {(localStorage.getItem("userRole") === "APPROVER" || localStorage.getItem("userRole") === "REVIEWER") && (
//                         <Box
//                             className="inspectionReportItem"
//                             sx={{
//                                 backgroundColor: showRecommendedActions ? theme.palette.colors[20] : "",
//                             }}
//                             onClick={displayRecommendedActions}
//                         >
//                             <ArrowRightIcon sx={{ fontSize: 30 }} />
//                             <Typography className="typographyFontWeight">Recommended Actions</Typography>
//                         </Box>
//                     )}
//                 </Grid2>
//                 <Grid2 size={9} container className="checklistContainer" ref={checklistContainerRef}>
//                     {!showInspectionReport && !showRecommendedActions && (
//                         <>
//                             {action && (action === "assign" || action === "review") && (
//                                 <Grid2
//                                     container
//                                     size={12}
//                                     sx={{
//                                         justifyContent: "space-between",
//                                         backgroundColor: "#E6EFF0",
//                                         borderRadius: "10px",
//                                         // borderRadius: "10px 10px 0px 0px",
//                                         alignItems: "center",
//                                         px: 2,
//                                         py: 0.5,
//                                     }}
//                                 >
//                                     <Typography>{categoryName}</Typography>
//                                     <FormControl className="newCaseFields" sx={{ width: "200px" }}>
//                                         <Select
//                                             value={categoryInspectorID}
//                                             onChange={(e) => updateCategoryInspector(e.target.value)}
//                                             disabled={action === "review"}
//                                         >
//                                             {groupInspectors?.map((inspector) => {
//                                                 return (
//                                                     <MenuItem key={inspector?.emailID} value={inspector?.emailID}>
//                                                         {inspector?.userName}
//                                                     </MenuItem>
//                                                 );
//                                             })}
//                                         </Select>
//                                     </FormControl>
//                                 </Grid2>
//                             )}
//                             <Grid2 container size={12} className="categoryChecklistContainer">
//                                 {categoryChecklistItems?.map((checklist, index) => {
//                                     return (
//                                         <>
//                                             <Grid2 container rowGap={2} sx={{ mb: 2, mt: 4 }} key={checklist.checklist_id}>
//                                                 <Grid2 container key={checklist.checklist_id} sx={{ alignItems: "center" }}>
//                                                     <Grid2 container>
//                                                         {isRedo && (
//                                                             <CustomCheckbox
//                                                                 checked={selectedItems.includes(checklist.checklist_id)}
//                                                                 onChange={(e) => handleCheckboxChange(e, checklist.checklist_id)}
//                                                             />
//                                                         )}
//                                                     </Grid2>
//                                                     <Grid2 container>
//                                                         <Typography className="typographyFontWeight">
//                                                             {checklist.checklist_name}
//                                                         </Typography>
//                                                     </Grid2>
//                                                 </Grid2>
//                                                 <Grid2 container size={12} sx={{ columnGap: 3, justifyContent: "space-between" }}>
//                                                     {checklist?.pre_defined_answer_type?.split("/")?.map((choice, index) => {
//                                                         return (
//                                                             <Button
//                                                                 variant="outlined"
//                                                                 key={choice + index}
//                                                                 className="choiceButton"
//                                                                 disabled={localStorage.getItem("userRole") !== "INSPECTOR"}
//                                                                 sx={{
//                                                                     backgroundColor:
//                                                                         checklist?.selected_answer === choice
//                                                                             ? theme.palette.colors[20]
//                                                                             : "",
//                                                                     fontWeight: checklist?.answer === choice ? 700 : "",
//                                                                 }}
//                                                                 onClick={() => updateChecklistAnswer(checklist, choice)}
//                                                             >
//                                                                 {choice}
//                                                             </Button>
//                                                         );
//                                                     })}
//                                                 </Grid2>
//                                             </Grid2>
//                                             {localStorage.getItem("userRole") === "INSPECTOR" && (
//                                                 <Grid2 container size={12} direction="column">
//                                                     {/* CoPilot */}
//                                                     <Typography className="typographyFontWeight">Co-Pilot</Typography>
//                                                     <TextField
//                                                         placeholder="Ask Anything"
//                                                         size="small"
//                                                         className="multilineInput"
//                                                         value={inputs[checklist.checklist_id] || ""}
//                                                         onChange={(e) => handleInputChange(e, checklist.checklist_id)}
//                                                         fullWidth
//                                                     />
//                                                     <Box
//                                                         sx={{
//                                                             display: "flex",
//                                                             justifyContent: "flex-end",
//                                                             gap: 1,
//                                                             ".MuiButtonBase-root": {
//                                                                 border: "1px solid #EBEBEB",
//                                                                 backgroundColor: "#EBEBEB",
//                                                                 borderRadius: "6px",
//                                                                 color: "#00060A",
//                                                                 px: 3,
//                                                             },
//                                                         }}
//                                                     >
//                                                         <Button onClick={() => handleClear(checklist.checklist_id)}>Clear</Button>
//                                                         <Button onClick={() => handleSubmit(checklist.checklist_id)}>
//                                                             Ask Co-Pilot
//                                                         </Button>
//                                                     </Box>
//                                                     <Typography className="typographyFontWeight">Answer</Typography>
//                                                     <TextField
//                                                         placeholder="Answer"
//                                                         size="small"
//                                                         className="multilineInput"
//                                                         value={apiData[checklist.checklist_id] || ""}
//                                                         slotProps={{
//                                                             input: {
//                                                                 readOnly: true,
//                                                             },
//                                                         }}
//                                                         fullWidth
//                                                         multiline
//                                                         rows={4}
//                                                     />
//                                                     {apiData[checklist.checklist_id] && (
//                                                         <Box
//                                                             sx={{
//                                                                 textAlign: "right",
//                                                                 marginTop: "-10px",
//                                                                 padding: "8px 0",
//                                                                 position: "relative",
//                                                                 top: "0",
//                                                                 right: "14px",
//                                                             }}
//                                                         >
//                                                             <Link
//                                                                 href="#"
//                                                                 onClick={(e) => {
//                                                                     setDisplayNote(`note${checklist.checklist_id}`);
//                                                                     handleAddToNotes(e, checklist);
//                                                                 }}
//                                                                 sx={{ color: "blue" }}
//                                                             >
//                                                                 Add to Notes
//                                                             </Link>
//                                                         </Box>
//                                                     )}
//                                                 </Grid2>
//                                             )}
//                                             <Divider sx={{ my: 1, width: "100%" }} />
//                                             <>
//                                                 {localStorage.getItem("userRole") === "INSPECTOR" && (
//                                                     <Box display="flex" columnGap={3} mr={3}>
//                                                         <Box className="attchmentsContainer">
//                                                             <Button
//                                                                 component="label"
//                                                                 role={undefined}
//                                                                 tabIndex={-1}
//                                                                 sx={{
//                                                                     fontWeight: 500,
//                                                                     color: "black",
//                                                                     fontSize: 14,
//                                                                     height: "25px",
//                                                                 }}
//                                                                 startIcon={<AttachFileIcon sx={{ fontSize: 12 }} />}
//                                                             >
//                                                                 <VisuallyHiddenInput
//                                                                     type="file"
//                                                                     accept="image/*"
//                                                                     onChange={(e) => {
//                                                                         attchImage(e, checklist);
//                                                                     }}
//                                                                 />
//                                                                 Attach Image
//                                                             </Button>
//                                                         </Box>
//                                                         <Box
//                                                             className="attchmentsContainer"
//                                                             onClick={() => setDisplayNote(`note${checklist.checklist_id}`)}
//                                                         >
//                                                             <img src={AddNotes} alt="Add notes" />
//                                                             <Typography ml={1} className="typographyFontWeight">
//                                                                 Add Notes
//                                                             </Typography>
//                                                         </Box>
//                                                     </Box>
//                                                 )}
//                                                 <Box
//                                                     className="attchmentsContainer"
//                                                     onClick={() => {
//                                                         setIsEditCorrectiveAction(false);
//                                                         setDisplayAddAction(`correctiveAction${checklist.checklist_id}`);
//                                                     }}
//                                                 >
//                                                     <AddActionsOutlinedIcon sx={{ mr: 1 }} />
//                                                     <Typography className="typographyFontWeight">
//                                                         Add Corrective Actions
//                                                     </Typography>
//                                                 </Box>
//                                                 <Divider sx={{ my: 1, width: "100%" }} />
//                                             </>
//                                             {checklist?.attachments?.length > 0 && (
//                                                 <>
//                                                     <Box>
//                                                         <Typography className="headingFontWeight">Documents</Typography>
//                                                         <Box className="attachmentContainer">
//                                                             {checklist?.attachments?.map((attachment, index) => {
//                                                                 return (
//                                                                     <Box className="attachmentItem" key={index}>
//                                                                         <Box className="imageContainer">
//                                                                             <img
//                                                                                 src={getImageThumbnail(attachment)}
//                                                                                 alt={attachment.name}
//                                                                                 className="attchmentImage"
//                                                                             />
//                                                                             <Typography className="attachmentTextStyle">
//                                                                                 {attachment.name?.length > 10
//                                                                                     ? attachment.name?.slice(0, 9) + "..."
//                                                                                     : attachment.name}
//                                                                             </Typography>
//                                                                         </Box>
//                                                                         <Box className="imageDownload">
//                                                                             <img src={DownloadImage} alt="Download" />
//                                                                         </Box>
//                                                                     </Box>
//                                                                 );
//                                                             })}
//                                                         </Box>
//                                                     </Box>
//                                                     <Divider sx={{ my: 1, width: "100%" }} />
//                                                 </>
//                                             )}
//                                             {(checklist?.comment || displayNote === `note${checklist.checklist_id}`) && (
//                                                 <>
//                                                     <Box width="100%">
//                                                         <Typography className="headingFontWeight">Note</Typography>
//                                                         <TextField
//                                                             size="small"
//                                                             fullWidth
//                                                             disabled={localStorage.getItem("userRole") !== "INSPECTOR"}
//                                                             rows={2}
//                                                             className="multilineInput"
//                                                             multiline
//                                                             value={checklist?.comment}
//                                                             onChange={(e) => updateChecklistNote(e, checklist)}
//                                                         />
//                                                     </Box>
//                                                     <Divider sx={{ my: 1, width: "100%" }} />
//                                                 </>
//                                             )}
//                                             {displayAddAction === `correctiveAction${checklist.checklist_id}` && (
//                                                 <>
//                                                     <Box width="100%">
//                                                         <Typography className="headingFontWeight">Corrective Actions</Typography>
//                                                         <Box className="correctiveActionContainer">
//                                                             <TextField
//                                                                 size="small"
//                                                                 fullWidth
//                                                                 className="correctiveActionField"
//                                                                 value={correctiveAction}
//                                                                 onChange={(e) => setCorrectiveAction(e.target.value)}
//                                                             />
//                                                         </Box>
//                                                         <Box className="iconContainer">
//                                                             <IconButton onClick={() => setDisplayAddAction("")}>
//                                                                 <CloseIcon sx={{ color: "#d54b4b", fontWeight: "bold" }} />
//                                                             </IconButton>
//                                                             <IconButton
//                                                                 onClick={() => {
//                                                                     updateCorrectiveActions(checklist);
//                                                                 }}
//                                                             >
//                                                                 <CheckIcon sx={{ color: "#03911a", fontWeight: "bold" }} />
//                                                             </IconButton>
//                                                         </Box>
//                                                     </Box>
//                                                     <Divider sx={{ mt: 1, mb: 3, width: "100%" }} />
//                                                 </>
//                                             )}
//                                             {checklist.selected_corrective_action?.filter((action) => action !== "")?.length >
//                                                 0 && (
//                                                 <>
//                                                     <Box width="100%">
//                                                         <Typography className="headingFontWeight">Corrective Actions</Typography>
//                                                         {checklist.selected_corrective_action?.map(
//                                                             (action, index) =>
//                                                                 action && (
//                                                                     <Box key={index} className="correctiveActions">
//                                                                         {isEditCorrectiveAction &&
//                                                                         index === correctiveActionId ? (
//                                                                             <Box
//                                                                                 sx={{
//                                                                                     display: "flex",
//                                                                                     flexDirection: "column",
//                                                                                     width: "100%",
//                                                                                 }}
//                                                                             >
//                                                                                 <TextField
//                                                                                     size="small"
//                                                                                     fullWidth
//                                                                                     className="correctiveActionField"
//                                                                                     value={editedCorrectiveAction}
//                                                                                     onChange={(e) =>
//                                                                                         setEditedCorrectiveAction(e.target.value)
//                                                                                     }
//                                                                                 />
//                                                                                 <Box className="iconContainer">
//                                                                                     <IconButton
//                                                                                         onClick={() =>
//                                                                                             setIsEditCorrectiveAction(false)
//                                                                                         }
//                                                                                     >
//                                                                                         <CloseIcon
//                                                                                             sx={{
//                                                                                                 color: "#d54b4b",
//                                                                                                 fontWeight: "bold",
//                                                                                             }}
//                                                                                         />
//                                                                                     </IconButton>
//                                                                                     <IconButton
//                                                                                         onClick={() => {
//                                                                                             editCorrectiveAction(
//                                                                                                 checklist,
//                                                                                                 action
//                                                                                             );
//                                                                                         }}
//                                                                                     >
//                                                                                         <CheckIcon
//                                                                                             sx={{
//                                                                                                 color: "#03911a",
//                                                                                                 fontWeight: "bold",
//                                                                                             }}
//                                                                                         />
//                                                                                     </IconButton>
//                                                                                 </Box>
//                                                                             </Box>
//                                                                         ) : (
//                                                                             <>
//                                                                                 <Typography className="typographyFontWeight">
//                                                                                     {action}
//                                                                                 </Typography>
//                                                                                 <Box>
//                                                                                     <IconButton
//                                                                                         onClick={() => {
//                                                                                             if (!isEditCorrectiveAction) {
//                                                                                                 setCorrectiveActionId(index);
//                                                                                                 setIsEditCorrectiveAction(true);
//                                                                                                 setEditedCorrectiveAction(action);
//                                                                                             }
//                                                                                         }}
//                                                                                     >
//                                                                                         <EditOutlinedIcon
//                                                                                             sx={{
//                                                                                                 color: "#03911a",
//                                                                                                 fontWeight: "bold",
//                                                                                             }}
//                                                                                         />
//                                                                                     </IconButton>
//                                                                                     <IconButton
//                                                                                         onClick={() =>
//                                                                                             deleteCorrectiveAction(
//                                                                                                 checklist,
//                                                                                                 action
//                                                                                             )
//                                                                                         }
//                                                                                     >
//                                                                                         <DeleteOutlinedIcon
//                                                                                             sx={{
//                                                                                                 color: "#d54b4b",
//                                                                                                 fontWeight: "bold",
//                                                                                             }}
//                                                                                         />
//                                                                                     </IconButton>
//                                                                                 </Box>
//                                                                             </>
//                                                                         )}
//                                                                     </Box>
//                                                                 )
//                                                         )}
//                                                     </Box>
//                                                     <Divider sx={{ mt: 1, mb: 3, width: "100%" }} />
//                                                 </>
//                                             )}
//                                         </>
//                                     );
//                                 })}
//                             </Grid2>

//                             {(localStorage.getItem("userRole") === "REVIEWER" ||
//                                 localStorage.getItem("userRole") === "APPROVER") && (
//                                 <Grid2 container size={12} sx={{ mt: 2 }}>
//                                     <Typography className="headingFontWeight" variant="h5">
//                                         Reviewer's Comments
//                                     </Typography>
//                                     <TextField
//                                         size="small"
//                                         fullWidth
//                                         rows={3}
//                                         disabled={localStorage.getItem("userRole") === "APPROVER"}
//                                         className="multilineInput"
//                                         multiline
//                                         value={reviwerCategoryReport}
//                                         onChange={(e) => setReviwerCategoryReport(e.target.value)}
//                                     />
//                                 </Grid2>
//                             )}
//                             {localStorage.getItem("userRole") === "APPROVER" && (
//                                 <Grid2 container size={12} sx={{ mt: 2 }}>
//                                     <Typography className="headingFontWeight" variant="h5">
//                                         Approver's Report
//                                     </Typography>
//                                     <TextField
//                                         size="small"
//                                         fullWidth
//                                         rows={3}
//                                         className="multilineInput"
//                                         multiline
//                                         value={approverCategoryReport}
//                                         onChange={(e) => setApproverCategoryReport(e.target.value)}
//                                     />
//                                 </Grid2>
//                             )}
//                         </>
//                     )}
//                     {showInspectionReport && (
//                         <Grid2 size={12} container direction="column">
//                             <Typography className="headingFontWeight" variant="h5">
//                                 Inspection Report
//                             </Typography>
//                             <TextField
//                                 size="small"
//                                 fullWidth
//                                 disabled={localStorage.getItem("userRole") !== "INSPECTOR"}
//                                 rows={3}
//                                 className="multilineInput"
//                                 multiline
//                                 value={inspectionReport}
//                                 onChange={(e) => setInspectionReport(e.target.value)}
//                             />
//                         </Grid2>
//                     )}
//                     {showRecommendedActions && localStorage.getItem("userRole") === "APPROVER" && (
//                         <Grid2 container size={12} direction={"column"} className="recommendedActionsContainer">
//                             <Typography className="headingFontWeight" variant="h5">
//                                 Recommended Actions
//                             </Typography>
//                             <Grid2 container size={12}>
//                                 <RadioGroup
//                                     aria-labelledby="demo-radio-buttons-group-label"
//                                     defaultValue="female"
//                                     name="radio-buttons-group"
//                                     value={recommendedAction}
//                                     onChange={(e) => setRecommendedAction(e.target.value)}
//                                     sx={{
//                                         width: "100%",
//                                     }}
//                                 >
//                                     <Box
//                                         sx={{
//                                             border: recommendedAction === "No Action" ? `2px solid #4C8B92` : `1px solid #CCCCCC`,
//                                             borderRadius: "6px",
//                                             opacity: 1,
//                                             px: 2,
//                                             py: 1,
//                                             mb: 2,
//                                         }}
//                                     >
//                                         <FormControlLabel
//                                             value="No Action"
//                                             control={<CustomRadio sx={{ mr: 1 }} />}
//                                             label={
//                                                 <>
//                                                     <Typography
//                                                         variant="h6"
//                                                         color={recommendedAction === "No Action" ? "#4C8B92" : "#00060A"}
//                                                     >
//                                                         No Action Required
//                                                     </Typography>
//                                                     <Typography fontSize="12px" color="#6A6969">
//                                                         No action required, Inspection has been completed successfully.
//                                                     </Typography>
//                                                 </>
//                                             }
//                                         />
//                                     </Box>
//                                     <Box
//                                         sx={{
//                                             border: recommendedAction === "Follow Up" ? `2px solid #4C8B92` : `1px solid #CCCCCC`,
//                                             borderRadius: "6px",
//                                             opacity: 1,
//                                             px: 2,
//                                             py: 1,
//                                             mb: 2,
//                                         }}
//                                     >
//                                         <FormControlLabel
//                                             value="Follow Up"
//                                             control={<CustomRadio sx={{ mr: 1 }} />}
//                                             label={
//                                                 <>
//                                                     <Typography
//                                                         variant="h6"
//                                                         color={recommendedAction === "Follow Up" ? "#4C8B92" : "#00060A"}
//                                                     >
//                                                         Follow Up Required
//                                                     </Typography>
//                                                     <Typography fontSize="12px" color="#6A6969">
//                                                         Follow up required, please select a date for follow up and complete the
//                                                         case.
//                                                     </Typography>
//                                                 </>
//                                             }
//                                         />
//                                     </Box>
//                                     <Box
//                                         sx={{
//                                             border:
//                                                 recommendedAction === "Re-Inspection" ? `2px solid #4C8B92` : `1px solid #CCCCCC`,
//                                             borderRadius: "6px",
//                                             opacity: 1,
//                                             px: 2,
//                                             py: 1,
//                                         }}
//                                     >
//                                         <FormControlLabel
//                                             value="Re-Inspection"
//                                             control={<CustomRadio sx={{ mr: 1 }} />}
//                                             label={
//                                                 <>
//                                                     <Typography
//                                                         variant="h6"
//                                                         color={recommendedAction === "Re-Inspection" ? "#4C8B92" : "#00060A"}
//                                                     >
//                                                         Re-Inspection Required
//                                                     </Typography>
//                                                     <Typography fontSize="12px" color="#6A6969">
//                                                         Re-Inspection required, please select a date for re-inspection and
//                                                         complete the case.
//                                                     </Typography>
//                                                 </>
//                                             }
//                                         />
//                                     </Box>
//                                 </RadioGroup>
//                             </Grid2>
//                             {(recommendedAction === "Follow Up" || recommendedAction === "Re-Inspection") && (
//                                 <Grid2 container size={12} spacing={0} direction={"column"} sx={{ mb: 1 }}>
//                                     <Typography variant="h6">
//                                         {recommendedAction === "Follow Up" ? "Follow Up Date" : "Re Inspection Date"}
//                                     </Typography>

//                                     <LocalizationProvider
//                                         dateAdapter={AdapterDayjs}
//                                         localeText={{
//                                             fieldDayPlaceholder: () => "DD",
//                                             fieldMonthPlaceholder: () => "MMM",
//                                             fieldYearPlaceholder: () => "YYYY",
//                                         }}
//                                     >
//                                         <DatePicker
//                                             size="small"
//                                             value={inspectionDate}
//                                             onChange={(value) =>
//                                                 recommendedAction === "Follow Up"
//                                                     ? setFollowUpDate(dayjs(value).format("YYYY-MM-DD"))
//                                                     : recommendedAction === "Re-Inspection"
//                                                     ? setReInspectionDate(dayjs(value).format("YYYY-MM-DD"))
//                                                     : ""
//                                             }
//                                             format="DD MMM YYYY"
//                                             className="dateField"
//                                             sx={{ height: "40px", width: "370px" }}
//                                             required
//                                         />
//                                     </LocalizationProvider>
//                                 </Grid2>
//                             )}
//                             {recommendedAction && (
//                                 <>
//                                     <Grid2 container size={12} sx={{ marginBottom: "10px" }}>
//                                         <Typography className="headingFontWeight" variant="h5">
//                                             Inspection Summary Report
//                                         </Typography>
//                                         <TextField
//                                             size="small"
//                                             fullWidth
//                                             rows={3}
//                                             className="multilineInput"
//                                             multiline
//                                             value={inspectionSummaryReport}
//                                             onChange={(e) => setInspectionSummaryReport(e.target.value)}
//                                         />
//                                     </Grid2>
//                                 </>
//                             )}
//                         </Grid2>
//                     )}
//                     {showRecommendedActions && localStorage.getItem("userRole") === "REVIEWER" && (
//                         <Grid2 container size={12} direction={"column"} className="recommendedActionsContainer">
//                             <Typography className="headingFontWeight" variant="h5">
//                                 Recommended Actions
//                             </Typography>
//                             <Grid2 container size={12}>
//                                 <RadioGroup
//                                     aria-labelledby="demo-radio-buttons-group-label"
//                                     defaultValue="female"
//                                     name="radio-buttons-group"
//                                     value={recommendedAction}
//                                     onChange={(e) => setRecommendedAction(e.target.value)}
//                                     sx={{
//                                         width: "100%",
//                                     }}
//                                 >
//                                     <Box
//                                         sx={{
//                                             border: recommendedAction === "Pass" ? `2px solid #4C8B92` : `1px solid #CCCCCC`,
//                                             borderRadius: "6px",
//                                             opacity: 1,
//                                             px: 2,
//                                             py: 1,
//                                             mb: 2,
//                                         }}
//                                     >
//                                         <FormControlLabel
//                                             value="Pass"
//                                             control={<CustomRadio sx={{ mr: 1 }} />}
//                                             label={
//                                                 <>
//                                                     <Typography
//                                                         variant="h6"
//                                                         color={recommendedAction === "Pass" ? "#4C8B92" : "#00060A"}
//                                                     >
//                                                         Pass
//                                                     </Typography>
//                                                     <Typography fontSize="12px" color="#6A6969">
//                                                         Passed at reviewer stage and will be sent to Approver
//                                                     </Typography>
//                                                 </>
//                                             }
//                                         />
//                                     </Box>
//                                     <Box
//                                         sx={{
//                                             border:
//                                                 recommendedAction === "Fail" ||
//                                                 recommendedAction === "Redo" ||
//                                                 recommendedAction === "Re-Inspection"
//                                                     ? `2px solid #4C8B92`
//                                                     : `1px solid #CCCCCC`,
//                                             borderRadius: "6px",
//                                             opacity: 1,
//                                             px: 2,
//                                             py: 1,
//                                             mb: 2,
//                                         }}
//                                     >
//                                         <FormControlLabel
//                                             value="Fail"
//                                             control={<CustomRadio sx={{ mr: 1 }} />}
//                                             label={
//                                                 <>
//                                                     <Typography
//                                                         variant="h6"
//                                                         color={recommendedAction === "Fail" ? "#4C8B92" : "#00060A"}
//                                                     >
//                                                         Fail
//                                                     </Typography>
//                                                     <Typography fontSize="12px" color="#6A6969">
//                                                         Please select the next step from following and complete the case
//                                                     </Typography>
//                                                 </>
//                                             }
//                                         />

//                                         {(recommendedAction === "Fail" ||
//                                             recommendedAction === "Redo" ||
//                                             recommendedAction === "Re-Inspection") && (
//                                             <>
//                                                 <Box
//                                                     sx={{
//                                                         border:
//                                                             recommendedAction === "Redo"
//                                                                 ? `2px solid #4C8B92`
//                                                                 : `1px solid #CCCCCC`,
//                                                         borderRadius: "6px",
//                                                         opacity: 1,
//                                                         px: 2,
//                                                         py: 1,
//                                                         mb: 2,
//                                                         mt: 3,
//                                                         mx: 2,
//                                                     }}
//                                                 >
//                                                     <FormControlLabel
//                                                         value="Redo"
//                                                         control={<CustomRadio sx={{ mr: 1 }} />}
//                                                         label={
//                                                             <>
//                                                                 <Typography
//                                                                     variant="h6"
//                                                                     color={recommendedAction === "Redo" ? "#4C8B92" : "#00060A"}
//                                                                 >
//                                                                     Redo
//                                                                 </Typography>
//                                                                 <Typography fontSize="12px" color="#6A6969">
//                                                                     Please select checklist items needed for redo and send the
//                                                                     case back to inspector{" "}
//                                                                 </Typography>
//                                                             </>
//                                                         }
//                                                     />
//                                                 </Box>
//                                                 <Box
//                                                     sx={{
//                                                         border:
//                                                             recommendedAction === "Re-Inspection"
//                                                                 ? `2px solid #4C8B92`
//                                                                 : `1px solid #CCCCCC`,
//                                                         borderRadius: "6px",
//                                                         opacity: 1,
//                                                         px: 2,
//                                                         py: 1,
//                                                         mb: 2,
//                                                         mx: 2,
//                                                     }}
//                                                 >
//                                                     <FormControlLabel
//                                                         value="Re-Inspection"
//                                                         control={<CustomRadio sx={{ mr: 1 }} />}
//                                                         label={
//                                                             <>
//                                                                 <Typography
//                                                                     variant="h6"
//                                                                     color={
//                                                                         recommendedAction === "Re-Inspection"
//                                                                             ? "#4C8B92"
//                                                                             : "#00060A"
//                                                                     }
//                                                                 >
//                                                                     Re-Inspection Required
//                                                                 </Typography>
//                                                                 <Typography fontSize="12px" color="#6A6969">
//                                                                     Re-Inspection required,please select a date for re-inspection
//                                                                     and complete the case{" "}
//                                                                 </Typography>
//                                                             </>
//                                                         }
//                                                     />
//                                                 </Box>
//                                             </>
//                                         )}
//                                     </Box>
//                                 </RadioGroup>
//                             </Grid2>
//                             {recommendedAction === "Re-Inspection" && (
//                                 <Grid2 container size={12} direction={"column"} sx={{ mb: 3 }}>
//                                     <Typography variant="h6" className="headingFontWeight">
//                                         Re Inspection Required{" "}
//                                     </Typography>
//                                     <LocalizationProvider
//                                         dateAdapter={AdapterDayjs}
//                                         localeText={{
//                                             fieldDayPlaceholder: () => "Choose date",
//                                             fieldMonthPlaceholder: () => "",
//                                             fieldYearPlaceholder: () => "",
//                                         }}
//                                     >
//                                         <DatePicker
//                                             size="small"
//                                             value={inspectionDate}
//                                             onChange={(value) => setReInspectionDate(dayjs(value).format("YYYY-MM-DD"))}
//                                             //renderInput={(params) => <TextField {...params} placeholder="Choose date" />}
//                                             format="DD MMM YYYY"
//                                             className="dateField"
//                                             sx={{ height: "40px", width: "370px" }}
//                                             required
//                                         />
//                                     </LocalizationProvider>
//                                 </Grid2>
//                             )}
//                             {recommendedAction === "Redo" && (
//                                 <Button
//                                     sx={{
//                                         border: "2px dashed #CCCCCC",
//                                         borderRadius: "6px",
//                                         padding: "16px",
//                                         display: "flex",
//                                         justifyContent: "space-between",
//                                         alignItems: "center",
//                                         backgroundColor: "#F8F9FA",
//                                         width: "100%",
//                                         textAlign: "left",
//                                         textTransform: "none",
//                                         mb: 2,
//                                     }}
//                                     onClick={handleGoBackFromRedo}
//                                 >
//                                     <Box sx={{ display: "flex", gap: "15px" }}>
//                                         <Box>
//                                             <AddIcon fontSize="large" sx={{ color: "grey" }} />
//                                         </Box>
//                                         <Box>
//                                             <Typography
//                                                 variant="h6"
//                                                 sx={{
//                                                     fontSize: "14px",
//                                                     color: "#6A6969",
//                                                 }}
//                                             >
//                                                 Select Checklist for Redo
//                                             </Typography>
//                                             <Typography sx={{ fontSize: "12px", color: "#6A6969" }}>
//                                                 Checklist selected will be marked for "Redo" when Inspector reopens the case
//                                             </Typography>
//                                         </Box>
//                                     </Box>
//                                     <Box
//                                         sx={{
//                                             display: "flex",
//                                             justifyContent: "center",
//                                             alignItems: "center",
//                                             borderRadius: "4px",
//                                             backgroundColor: "#E1F5F8",
//                                             padding: "4px 16px",
//                                             fontSize: "16px",
//                                             color: "#4C8B92",
//                                         }}
//                                     >
//                                         4/24 Selected
//                                     </Box>
//                                 </Button>
//                             )}
//                             {(recommendedAction === "Pass" ||
//                                 recommendedAction === "Redo" ||
//                                 recommendedAction === "Re-Inspection") && (
//                                 <>
//                                     <Grid2 container size={12} sx={{ marginBottom: "10px" }}>
//                                         <Typography className="headingFontWeight" variant="h5">
//                                             Inspection Summary Report
//                                         </Typography>
//                                         <TextField
//                                             size="small"
//                                             fullWidth
//                                             rows={3}
//                                             className="multilineInput"
//                                             multiline
//                                             value={inspectionSummaryReport}
//                                             onChange={(e) => setInspectionSummaryReport(e.target.value)}
//                                         />
//                                     </Grid2>
//                                 </>
//                             )}
//                         </Grid2>
//                     )}
//                     <Grid2 container size={12} columnGap={3} sx={{ justifyContent: "flex-end" }}>
//                         <Button
//                             variant="outlined"
//                             className="saveButton"
//                             onClick={() => {
//                                 if (localStorage.getItem("userRole") === "INSPECTOR") {
//                                     if (action === "assign") {
//                                         assignCategoriesToInspectors();
//                                     } else {
//                                         saveInspection();
//                                     }
//                                 }
//                                 if (localStorage.getItem("userRole") === "APPROVER") {
//                                     saveSubmitReviewerApproval("save", recommendedAction, followUpDate, ReInspectionDate);
//                                 }
//                                 if (localStorage.getItem("userRole") === "REVIEWER") {
//                                     saveSubmitReviewerApproval("save", recommendedAction, followUpDate, ReInspectionDate);
//                                 }
//                             }}
//                         >
//                             Save
//                         </Button>
//                         {((localStorage.getItem("userRole") === "INSPECTOR" && !showInspectionReport) ||
//                             (localStorage.getItem("userRole") === "APPROVER" && !showRecommendedActions) ||
//                             (localStorage.getItem("userRole") === "REVIEWER" && !showRecommendedActions)) && (
//                             <Button
//                                 className="nextSubmitButton"
//                                 disabled={action === "assign" && currentChecklistId.current === inspectionChecklist?.length - 1}
//                                 onClick={() => {
//                                     if (currentChecklistId.current < inspectionChecklist?.length - 1) {
//                                         if (showInspectionReport) {
//                                             currentChecklistId.current = 0;
//                                         } else {
//                                             currentChecklistId.current = currentChecklistId.current + 1;
//                                         }
//                                         updateInspectionChecklist();
//                                     } else {
//                                         if (localStorage.getItem("userRole") === "INSPECTOR") {
//                                             displayInspectionReport();
//                                         } else if (localStorage.getItem("userRole") === "APPROVER") {
//                                             displayRecommendedActions();
//                                         } else if (localStorage.getItem("userRole") === "REVIEWER") {
//                                             displayRecommendedActions();
//                                         }
//                                     }
//                                 }}
//                             >
//                                 Next
//                             </Button>
//                         )}
//                         {((localStorage.getItem("userRole") === "INSPECTOR" && showInspectionReport) ||
//                             (localStorage.getItem("userRole") === "APPROVER" && showRecommendedActions) ||
//                             (localStorage.getItem("userRole") === "REVIEWER" && showRecommendedActions)) && (
//                             <Button
//                                 className="nextSubmitButton"
//                                 onClick={() => {
//                                     if (localStorage.getItem("userRole") === "INSPECTOR") {
//                                         if (caseDetails?.caseCreationType === "individual") {
//                                             submitInspection();
//                                         } else if (
//                                             action === "review" &&
//                                             (caseDetails?.caseCreationType === "group" ||
//                                                 caseDetails?.caseCreationType === "plan") &&
//                                             caseDetails?.leadId === parseInt(localStorage.getItem("userID"))
//                                         ) {
//                                             submitInspection();
//                                         } else {
//                                             saveInspection();
//                                         }
//                                     }
//                                     if (localStorage.getItem("userRole") === "APPROVER") {
//                                         saveSubmitReviewerApproval("submit", recommendedAction, followUpDate, ReInspectionDate);
//                                     }
//                                     if (localStorage.getItem("userRole") === "REVIEWER") {
//                                         saveSubmitReviewerApproval("submit", recommendedAction, followUpDate, ReInspectionDate);
//                                     }
//                                 }}
//                                 sx={{
//                                     backgroundColor:
//                                         localStorage.getItem("userRole") === "REVIEWER" && !recommendedAction
//                                             ? "grey !important"
//                                             : "",
//                                     color:
//                                         localStorage.getItem("userRole") === "REVIEWER" && !recommendedAction
//                                             ? "white !important"
//                                             : "",
//                                 }}
//                                 disabled={localStorage.getItem("userRole") === "REVIEWER" && !recommendedAction}
//                             >
//                                 Submit
//                             </Button>
//                         )}
//                     </Grid2>
//                 </Grid2>
//             </Grid2>
//         </>
//     );
// };

// export default Checklist;
import React, { useContext, useEffect, useRef, useState } from "react";
import {
    Box,
    Typography,
    Grid2,
    Button,
    useTheme,
    Divider,
    styled,
    TextField,
    IconButton,
    CircularProgress,
    FormControlLabel,
    RadioGroup,
    Link,
    Checkbox,
    FormControl,
    Select,
    MenuItem,
} from "@mui/material";
import ArrowRightIcon from "@mui/icons-material/ArrowRight";
import CustomCheckbox from "../global/CustomCheckbox";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import AddActionsOutlinedIcon from "@mui/icons-material/PlaylistAddOutlined";
import AddNotes from "../../assets/add-notes.png";
import DownloadImage from "../../assets/download.png";
import CheckIcon from "@mui/icons-material/Check";
import CloseIcon from "@mui/icons-material/Close";
import "./checklist.css";
import axios from "axios";
import { SnackContext } from "../global/SnackProvider";
import { useNavigate } from "react-router-dom";
import CustomRadio from "../global/CustomRadio";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import AddIcon from "@mui/icons-material/Add";
import dayjs from "dayjs";
import Loader from "../global/Loader";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";

const Checklist = ({
    inspectionChecklists,
    inspectionID,
    inspectorReport,
    approverReport,
    action = "",
    groupInspectors = [],
    caseDetails,
}) => {
    console.log(caseDetails)
    console.log(caseDetails?.leadId)
    const theme = useTheme();
    const navigate = useNavigate();
    const [inspectionChecklist, setInspectionChecklist] = useState([]);
    const [categoryChecklist, setCategoryChecklist] = useState({});
    const [categoryChecklistItems, setCategoryChecklistItems] = useState([]);
    const [categoryName, setCategoryName] = useState("");
    const [correctiveAction, setCorrectiveAction] = useState("");
    const [displayNote, setDisplayNote] = useState("");
    const [displayAddAction, setDisplayAddAction] = useState("");
    const currentChecklistId = useRef(0);
    const [inspectionReport, setInspectionReport] = useState("");
    const [showInspectionReport, setShowInspectionReport] = useState(
        localStorage.getItem("userRole") === "INSPECTOR" ? false : true
    );
    const [showRecommendedActions, setShowRecommendedActions] = useState(false);
    const totalChecklistItems = useRef(0);
    const answeredChecklistItems = useRef(0);
    const checklistContainerRef = useRef(null);
    const { snack, setSnack } = useContext(SnackContext);
    const [isSaveInspection, setIsSaveInspection] = useState(false);
    const [approverCategoryReport, setApproverCategoryReport] = useState("");
    const [reviwerCategoryReport, setReviwerCategoryReport] = useState("");
    const [recommendedAction, setRecommendedAction] = useState(null);
    const [inspectionSummaryReport, setInspectionSummaryReport] = useState("");
    const [inspectionDate, setInspectionDate] = useState(null);
    const [followUpDate, setFollowUpDate] = useState(null);
    const [ReInspectionDate, setReInspectionDate] = useState(null);
    const [selectedchecklistitems, setSelectedChecklistItems] = useState([]);
    const [apiData, setApiData] = useState("");
    const categoryRefs = useRef([]);
    const [isRedo, setIsRedo] = useState(false);
    const [inputs, setInputs] = useState({});
    const [selectedItems, setSelectedItems] = useState([]);
    const [isEditCorrectiveAction, setIsEditCorrectiveAction] = useState(false);
    const [editedCorrectiveAction, setEditedCorrectiveAction] = useState("");
    const answeredChecklistCount = useRef({});
    const [correctiveActionId, setCorrectiveActionId] = useState(null);
    const [categoryInspectorID, setCategoryInspectorID] = useState("");

    const VisuallyHiddenInput = styled("input")`
        clip: rect(0 0 0 0);
        clip-path: inset(50%);
        height: 1px;
        overflow: hidden;
        position: absolute;
        bottom: 0;
        left: 0;
        white-space: nowrap;
        width: 1px;
    `;

    useEffect(() => {
        if (checklistContainerRef.current) {
            checklistContainerRef.current.scrollTop = 0;
        }
    }, [inspectionChecklist[currentChecklistId.current]]);

    useEffect(() => {
        setInspectionChecklist(inspectionChecklists);
    }, [inspectionChecklists]);

    useEffect(() => {
        setInspectionReport(inspectorReport);
    }, [inspectorReport]);

    useEffect(() => {
        setInspectionSummaryReport(approverReport);
    }, [approverReport]);

    useEffect(() => {
        inspectionChecklists?.map((checklist) => {
            totalChecklistItems.current += checklist?.checklistItem?.length;
        });
        setCategoryChecklist(inspectionChecklists[0]);
        setCategoryChecklistItems(inspectionChecklists[0]?.checklistItem);
        setCategoryName(inspectionChecklists[0]?.categoryName);
        setCategoryInspectorID(inspectionChecklists[0]?.inspectorID);
    }, [inspectionChecklists]);

    useEffect(() => {
        setSelectedChecklistItems([]);
    }, [categoryChecklist]);

    const updateInspectionChecklist = () => {
        if (categoryChecklistItems.length > 0) {
            setInspectionChecklist((prevItems) => {
                return prevItems.map((item) => {
                    if (item?.categoryName === categoryName) {
                        return {
                            ...item,
                            checklistItem: categoryChecklistItems,
                            approverComment: approverCategoryReport,
                            reviewerComment: reviwerCategoryReport,
                        };
                    }
                    return item;
                });
            });
        }
        // setApproverCategoryReport('')
        setShowInspectionReport(false);
        setShowRecommendedActions(false);
        setCategoryChecklist(inspectionChecklist[currentChecklistId.current]);
        setCategoryChecklistItems(inspectionChecklist[currentChecklistId.current]?.checklistItem);
        setCategoryName(inspectionChecklist[currentChecklistId.current]?.categoryName);
        setCategoryInspectorID(inspectionChecklist[currentChecklistId.current]?.inspectorID);
        setApproverCategoryReport(
            inspectionChecklist[currentChecklistId.current]?.approverComment
                ? inspectionChecklist[currentChecklistId.current]?.approverComment
                : ""
        );
        setReviwerCategoryReport(
            inspectionChecklist[currentChecklistId.current]?.reviewerComment
                ? inspectionChecklist[currentChecklistId.current]?.reviewerComment
                : ""
        );
        setDisplayNote("");
        setDisplayAddAction("");
        if (categoryRefs.current[currentChecklistId.current]) {
            categoryRefs.current[currentChecklistId.current].focus(); // Focus on the clicked category
        }
    };

    const updateCategoryInspector = (inspectorId) => {
        setCategoryInspectorID(inspectorId);
        setInspectionChecklist((prevItems) => {
            return prevItems.map((item) => {
                if (item?.categoryName === categoryName) {
                    return {
                        ...item,
                        inspectorID: inspectorId,
                    };
                }
                return item;
            });
        });
    };

    const displayInspectionReport = () => {
        setInspectionChecklist((prevItems) => {
            return prevItems.map((item) => {
                if (item?.categoryName === categoryName) {
                    return {
                        ...item,
                        checklistItem: categoryChecklistItems,
                    };
                }
                return item;
            });
        });
        setCategoryChecklist({});
        setCategoryChecklistItems([]);
        setCategoryName("");
        setCategoryInspectorID("");
        setDisplayNote("");
        setDisplayAddAction("");
        setShowInspectionReport(true);
        setShowRecommendedActions(false);
    };

    const displayRecommendedActions = () => {
        setInspectionChecklist((prevItems) => {
            return prevItems.map((item) => {
                if (item?.categoryName === categoryName) {
                    return {
                        ...item,
                        checklistItem: categoryChecklistItems,
                        approverComment: approverCategoryReport,
                        reviewerComment: reviwerCategoryReport,
                    };
                }
                return item;
            });
        });
        setShowRecommendedActions(true);
        setShowInspectionReport(false);
    };

    const attchImage = async (e, checklist) => {
        const response = await getBase64(e);
        setCategoryChecklistItems((prevItems) => {
            return prevItems.map((item) => {
                if (item.checklist_name === checklist.checklist_name) {
                    return {
                        ...item,
                        attachments:
                            item.attachments?.length > 0 ? [...item.attachments, e.target.files[0]] : [e.target.files[0]],
                        attachmentsBase64:
                            item.attachmentsBase64?.length > 0 ? [...item.attachmentsBase64, response] : [response],
                    };
                }
                return item;
            });
        });
    };

    const getBase64 = async (e) => {
        return new Promise((resolve, reject) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onloadend = () => {
                    const base64String = reader.result.replace("data:", "").replace(/^.+,/, "");
                    resolve(base64String);
                };
                reader.onerror = (error) => reject(error);
                reader.readAsDataURL(file);
            } else {
                reject("No file selected");
            }
        });
    };

    const updateChecklistNote = (e, checklist) => {
        setCategoryChecklistItems((prevItems) => {
            return prevItems.map((item) => {
                if (item.checklist_name === checklist.checklist_name) {
                    return {
                        ...item,
                        comment: e.target.value,
                    };
                }
                return item;
            });
        });
    };

    const updateCorrectiveActions = (checklist) => {
        setCategoryChecklistItems((prevItems) => {
            return prevItems.map((item) => {
                if (item.checklist_name === checklist.checklist_name) {
                    return {
                        ...item,
                        selected_corrective_action:
                            item.selected_corrective_action?.length > 0
                                ? [...item.selected_corrective_action, correctiveAction]
                                : [correctiveAction],
                    };
                }
                return item;
            });
        });
        setDisplayAddAction("");
        setCorrectiveAction("");
    };

    const editCorrectiveAction = (checklist, action) => {
        setCategoryChecklistItems((prevItems) => {
            return prevItems.map((item) => {
                if (item.checklist_name === checklist.checklist_name) {
                    return {
                        ...item,
                        selected_corrective_action: item.selected_corrective_action?.map((correctiveAction) =>
                            correctiveAction === action ? editedCorrectiveAction : correctiveAction
                        ),
                    };
                }
                return item;
            });
        });
        setIsEditCorrectiveAction(false);
        setEditedCorrectiveAction("");
    };

    const deleteCorrectiveAction = (checklist, action) => {
        setCategoryChecklistItems((prevItems) => {
            return prevItems.map((item) => {
                if (item.checklist_name === checklist.checklist_name) {
                    return {
                        ...item,
                        selected_corrective_action: item.selected_corrective_action?.filter(
                            (corrctiveAction) => corrctiveAction !== action
                        ),
                    };
                }
                return item;
            });
        });
    };

    const updateChecklistAnswer = (checklist, choice) => {
        setCategoryChecklistItems((prevItems) => {
            return prevItems.map((item) => {
                if (item.checklist_name === checklist.checklist_name) {
                    return {
                        ...item,
                        selected_answer: choice,
                    };
                }
                return item;
            });
        });
        if (!answeredChecklistCount.current[categoryName]) {
            answeredChecklistCount.current[categoryName] = [checklist?.checklist_id];
            answeredChecklistItems.current = parseInt(answeredChecklistItems.current) + 1;
        } else {
            if (!answeredChecklistCount.current[categoryName].includes(checklist?.checklist_id)) {
                answeredChecklistCount.current[categoryName].push(checklist?.checklist_id);
                answeredChecklistItems.current = parseInt(answeredChecklistItems.current) + 1;
            }
        }
    };

    const getImageThumbnail = (attachment) => {
        if (typeof attachment === "string") {
            // Extract MIME type if present, otherwise default to 'image/png'
            const mimeTypeMatch = attachment.match(/^data:image\/(png|jpeg|jpg|gif|webp|bmp|svg\+xml);base64,/);
            const mimeType = mimeTypeMatch ? `image/${mimeTypeMatch[1]}` : "image/png";

            // Remove base64 prefix if it exists
            const base64Data = attachment.replace(/^data:image\/(png|jpeg|jpg|gif|webp|bmp|svg\+xml);base64,/, "");

            // Convert base64 to a Blob
            const byteCharacters = atob(base64Data);
            const byteNumbers = new Uint8Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const blob = new Blob([byteNumbers], { type: mimeType });

            return URL.createObjectURL(blob);
        }
        const imageUrl = URL.createObjectURL(attachment);
        return imageUrl;
    };

    const saveInspection = async () => {
        try {
            setIsSaveInspection(true);
            let submissionData = [];
            inspectionChecklist?.forEach((checklistCategory) => {
                if (checklistCategory?.categoryName === categoryName) {
                    categoryChecklistItems?.forEach((item) => {
                        submissionData.push({
                            id: {
                                inspectionID: inspectionID,
                                categoryID: checklistCategory?.categoryId,
                                checklistID: item?.checklist_id,
                            },
                            selected_answer: item?.selected_answer,
                            attachment: item?.attachmentsBase64 || null,
                            comment: item?.comment?.trim(),
                            corrective_actions: item?.selected_corrective_action || [],
                        });
                    });
                } else {
                    checklistCategory?.checklistItem?.forEach((item) => {
                        submissionData.push({
                            id: {
                                inspectionID: inspectionID,
                                categoryID: checklistCategory?.categoryId,
                                checklistID: item?.checklist_id,
                            },
                            selected_answer: item?.selected_answer,
                            attachment: item?.attachmentsBase64 || null,
                            comment: item?.comment?.trim(),
                            corrective_actions: item?.selected_corrective_action || [],
                        });
                    });
                }
            });
            const response = await axios({
                method: "post",
                url: `${import.meta.env.VITE_BASE_URL}/saveInspection`,
                data: {
                    inspectionChecklistandAnswers: submissionData,
                    inspectorComment: inspectionReport,
                },
            });
            if (response?.data?.status === "Failure") {
                setSnack({ open: true, message: "Something went wrong. Please try again.", severity: "error" });
            } else {
                setSnack({ open: true, message: "Inspection saved successfully.", severity: "success" });
            }
            setIsSaveInspection(false);
        } catch (error) {
            console.log(error);
            setIsSaveInspection(false);
            setSnack({ open: true, message: "An error occurred while saving the inspection.", severity: "error" });
        }
    };

    const submitInspection = async () => {
        try {
            setIsSaveInspection(true);
            let submissionData = [];
            inspectionChecklist?.map((checklistCategory) => {
                checklistCategory?.checklistItem?.map((item) => {
                    submissionData.push({
                        id: {
                            inspectionID: inspectionID,
                            categoryID: checklistCategory?.categoryId,
                            checklistID: item?.checklist_id,
                        },
                        selected_answer: item?.selected_answer,
                        attachment: item?.attachmentsBase64 || null,
                        comment: item?.comment?.trim(),
                        corrective_actions: item?.selected_corrective_action?.filter((action) => action !== "") || [],
                    });
                });
            });
            const response = await axios({
                method: "post",
                url: `${import.meta.env.VITE_BASE_URL}/submitInspection/${inspectionID}`,
                data: {
                    inspectionChecklistandAnswers: submissionData,
                    inspectorComment: inspectionReport,
                },
            });
            if (response?.data?.status === "Failure") {
                setSnack({ open: true, message: "Something went wrong. Please try again later.", severity: "error" });
            } else {
                setSnack({ open: true, message: "Inspection submitted successfully.", severity: "success" });
                navigate("/cases");
            }
            setIsSaveInspection(false);
        } catch (error) {
            console.log(error);
            setIsSaveInspection(false);
        }
    };

    const saveSubmitReviewerApproval = async (action, recommendedAction, dateOfFollowUp, ReInspectionDate) => {
        try {
            setIsSaveInspection(true);
            const reviewReport = [];
            inspectionChecklist?.map((checklist) => {
                reviewReport.push({
                    id: {
                        inspectionID: inspectionID,
                        categoryID: checklist?.categoryId,
                    },
                    approverComment: checklist?.approverComment,
                    reviewerComment: checklist?.reviewerComment,
                });
            });

            const userRole = localStorage.getItem("userRole");
            let inspectionStage = "review"; // Default to review
            if (userRole === "APPROVER") {
                inspectionStage = "approver";
            } else if (userRole === "REVIEWER") {
                inspectionStage = "review";
            }
            const response = await axios({
                method: "post",
                url: `${import.meta.env.VITE_BASE_URL}/reviewInspection`,
                data: {
                    inspectionId: inspectionID,
                    inspectionStage: inspectionStage,
                    approverReviewerComments: reviewReport,
                    overallComment: inspectionSummaryReport,
                    action: action,
                    recommendedAction: recommendedAction,
                    dateOfFollowUp: dateOfFollowUp,
                    dateOfReinspection: ReInspectionDate,
                },
            });

            if (action === "save") {
                setSnack({ open: true, message: "Saved Inspection Approval.", severity: "success" });
            }
            if (action === "submit") {
                setSnack({ open: true, message: "Inspection Approved Successfully.", severity: "success" });
                navigate(`/cases`);
            }

            setIsSaveInspection(false);
        } catch (error) {
            setIsSaveInspection(false);
            console.log("Error during review submission:", error);
            setSnack({ open: true, message: "Something went wrong. Please try again later.", severity: "error" });
        }
    };

    const fetchData = async (checklistId) => {
        try {
            setIsSaveInspection(true);
            const response = await axios.post(`${import.meta.env.VITE_BASE_URL}/askCopilot`, {
                prompt: inputs[checklistId] || "",
            });

            if (response.data.status === "SUCCESS") {
                setApiData((prevApiData) => ({
                    ...prevApiData,
                    [checklistId]: response.data.chatGPTResponse,
                }));
            } else {
                setApiData((prevApiData) => ({
                    ...prevApiData,
                    [checklistId]: "Error: Unable to fetch data",
                }));
            }
            setIsSaveInspection(false);
        } catch (error) {
            setIsSaveInspection(false);
            console.error("Error fetching data from API:", error);
            setApiData((prevApiData) => ({
                ...prevApiData,
                [checklistId]: "Error: Unable to fetch data",
            }));
        }
    };

    const handleInputChange = (event, checklistId) => {
        setInputs((prevInputs) => ({
            ...prevInputs,
            [checklistId]: event.target.value,
        }));
    };

    const handleSubmit = (checklistId) => {
        fetchData(checklistId);
    };

    const handleClear = (checklistId) => {
        setInputs((prevInputs) => ({
            ...prevInputs,
            [checklistId]: "",
        }));
    };

    const handleAddToNotes = (event, checklist) => {
        event.preventDefault();
        setCategoryChecklistItems((prevItems) => {
            return prevItems.map((item) => {
                if (item.checklist_name === checklist.checklist_name) {
                    return {
                        ...item,
                        comment: apiData[checklist.checklist_id],
                    };
                }
                return item;
            });
        });
    };

    const handleGoBackFromRedo = () => {
        setIsRedo(true);
        categoryRefs.current[currentChecklistId.current].click();
    };

    // Handle checkbox changes
    const handleCheckboxChange = (e, checklistId) => {
        const isChecked = e.target.checked;
        setSelectedItems((prevSelectedItems) => {
            if (isChecked) {
                return [...prevSelectedItems, checklistId];
            } else {
                return prevSelectedItems.filter((id) => id !== checklistId);
            }
        });
    };

    // const assignCategoriesToInspectors = async () => {
    //     try {
    //         let categoryInspectorMapping = [];
    //         inspectionChecklist?.map((checklist) => {
    //             let obj = {
    //                 assignTo: checklist?.inspectorID,
    //                 checklistCatId: checklist?.categoryId,
    //             };
    //             categoryInspectorMapping.push(obj);
    //         });
    //         console.log(categoryInspectorMapping);
    //         const response = await axios({
    //             method: "post",
    //             url: `${import.meta.env.VITE_BASE_URL}/assignCategory/${inspectionID}/Submit`,
    //             data: categoryInspectorMapping,
    //         });
    //         console.log(response);
    //     } catch (error) {
    //         console.log(error);
    //     }
    // };

    const assignCategoriesToInspectors = async (actionType) => {
        try {
            let categoryInspectorMapping = [];
            inspectionChecklist?.forEach((checklist) => {
                categoryInspectorMapping.push({
                    assignTo: checklist?.inspectorID,
                    checklistCatId: checklist?.categoryId,
                });
            });

            console.log(categoryInspectorMapping);

            const endpoint = actionType === 'save'
                ? `${import.meta.env.VITE_BASE_URL}/assignCategory/${inspectionID}/Save`
                : `${import.meta.env.VITE_BASE_URL}/assignCategory/${inspectionID}/Submit`;

            const response = await axios.post(endpoint, categoryInspectorMapping);
            console.log(response);
            if (response.status === 200) {
                console.log('Categories assigned successfully:', response.data);
                if (actionType === 'submit') {
                    navigate('/cases');
                }
            }
        } catch (error) {
            console.error('Error assigning categories:', error);
        }
    };

    return (
        <>
            <Grid2 container sx={{ m: 2.5 }} spacing={2.5}>
                {isSaveInspection && <Loader />}
                <Grid2 size={3} className="categoryContainer">
                    {(localStorage.getItem("userRole") === "REVIEWER" || localStorage.getItem("userRole") === "APPROVER") && (
                        <Box
                            className="inspectionReportItem"
                            sx={{
                                backgroundColor: showInspectionReport ? theme.palette.colors[20] : "",
                            }}
                            onClick={displayInspectionReport}
                        >
                            <ArrowRightIcon sx={{ fontSize: 30 }} />
                            <Typography className="typographyFontWeight">Inspection Report</Typography>
                        </Box>
                    )}
                    <Box display="flex" alignItems="center" justifyContent="space-between">
                        <Box display="flex" alignItems="center">
                            <ArrowRightIcon sx={{ fontSize: 30 }} />
                            <Typography className="typographyFontWeight">Categories</Typography>
                        </Box>
                        {localStorage.getItem("userRole") === "INSPECTOR" && (
                            <Box display="flex" pr={2}>
                                <Typography className="typographyFontWeight">
                                    {answeredChecklistItems.current}/{totalChecklistItems.current}
                                </Typography>
                            </Box>
                        )}
                    </Box>
                    <Box>
                        {inspectionChecklist?.map((category, index) => {
                            return (
                                <Box
                                    className="categoryItems"
                                    key={index}
                                    tabIndex={0}
                                    ref={(el) => (categoryRefs.current[index] = el)}
                                    sx={{
                                        backgroundColor:
                                            !showInspectionReport &&
                                                !showRecommendedActions &&
                                                category?.categoryId === categoryChecklist?.categoryId
                                                ? theme.palette.colors[20]
                                                : "",
                                    }}
                                    onClick={() => {
                                        currentChecklistId.current = index;
                                        updateInspectionChecklist();
                                    }}
                                >
                                    <Typography className="typographyFontWeight">
                                        {category.categoryName.length > 25
                                            ? category.categoryName.slice(0, 24) + "..."
                                            : category.categoryName}
                                    </Typography>
                                    {localStorage.getItem("userRole") === "INSPECTOR" && (
                                        <Typography className="typographyFontWeight">
                                            {answeredChecklistCount.current[category.categoryName]?.length}/
                                            {category.checklistItem.length}
                                        </Typography>
                                    )}
                                </Box>
                            );
                        })}
                    </Box>
                    {action !== "assign" && localStorage.getItem("userRole") === "INSPECTOR" && (
                        <Box
                            className="inspectionReportItem"
                            sx={{
                                backgroundColor: showInspectionReport ? theme.palette.colors[20] : "",
                            }}
                            onClick={displayInspectionReport}
                        >
                            <ArrowRightIcon sx={{ fontSize: 30 }} />
                            <Typography className="typographyFontWeight">Inspection Report</Typography>
                        </Box>
                    )}
                    {(localStorage.getItem("userRole") === "APPROVER" || localStorage.getItem("userRole") === "REVIEWER") && (
                        <Box
                            className="inspectionReportItem"
                            sx={{
                                backgroundColor: showRecommendedActions ? theme.palette.colors[20] : "",
                            }}
                            onClick={displayRecommendedActions}
                        >
                            <ArrowRightIcon sx={{ fontSize: 30 }} />
                            <Typography className="typographyFontWeight">Recommended Actions</Typography>
                        </Box>
                    )}
                </Grid2>
                <Grid2 size={9} container className="checklistContainer" ref={checklistContainerRef}>
                    {!showInspectionReport && !showRecommendedActions && (
                        <>
                            {action && (action === "assign" || action === "review") && (
                                <Grid2
                                    container
                                    size={12}
                                    sx={{
                                        justifyContent: "space-between",
                                        backgroundColor: "#E6EFF0",
                                        borderRadius: "10px",
                                        // borderRadius: "10px 10px 0px 0px",
                                        alignItems: "center",
                                        px: 2,
                                        py: 0.5,
                                    }}
                                >
                                    <Typography>{categoryName}</Typography>
                                    <FormControl className="newCaseFields" sx={{ width: "200px" }}>
                                        <Select
                                            value={categoryInspectorID}
                                            onChange={(e) => updateCategoryInspector(e.target.value)}
                                            disabled={action === "review"}
                                        >
                                            {groupInspectors?.map((inspector) => {
                                                return (
                                                    <MenuItem key={inspector?.emailID} value={inspector?.emailID}>
                                                        {inspector?.userName}
                                                    </MenuItem>
                                                );
                                            })}
                                        </Select>
                                    </FormControl>
                                </Grid2>
                            )}
                            <Grid2 container size={12} className="categoryChecklistContainer">
                                {categoryChecklistItems?.map((checklist, index) => {
                                    return (
                                        <>
                                            <Grid2 container rowGap={2} sx={{ mb: 2, mt: 4 }} key={checklist.checklist_id}>
                                                <Grid2 container key={checklist.checklist_id} sx={{ alignItems: "center" }}>
                                                    <Grid2 container>
                                                        {isRedo && (
                                                            <CustomCheckbox
                                                                checked={selectedItems.includes(checklist.checklist_id)}
                                                                onChange={(e) => handleCheckboxChange(e, checklist.checklist_id)}
                                                            />
                                                        )}
                                                    </Grid2>
                                                    <Grid2 container>
                                                        <Typography className="typographyFontWeight">
                                                            {checklist.checklist_name}
                                                        </Typography>
                                                    </Grid2>
                                                </Grid2>
                                                <Grid2 container size={12} sx={{ columnGap: 3, justifyContent: "space-between" }}>
                                                    {checklist?.pre_defined_answer_type?.split("/")?.map((choice, index) => {
                                                        return (
                                                            <Button
                                                                variant="outlined"
                                                                key={choice + index}
                                                                className="choiceButton"
                                                                // disabled={localStorage.getItem("userRole") !== "INSPECTOR" || !!caseDetails?.leadId}
                                                                sx={{
                                                                    backgroundColor:
                                                                        checklist?.selected_answer === choice
                                                                            ? theme.palette.colors[20]
                                                                            : "",
                                                                    fontWeight: checklist?.answer === choice ? 700 : "",
                                                                }}
                                                                onClick={() => updateChecklistAnswer(checklist, choice)}
                                                            >
                                                                {choice}
                                                            </Button>
                                                        );
                                                    })}
                                                </Grid2>
                                            </Grid2>
                                            {localStorage.getItem("userRole") === "INSPECTOR" && (
                                                <Grid2 container size={12} direction="column">
                                                    {/* CoPilot */}
                                                    <Typography className="typographyFontWeight">Co-Pilot</Typography>
                                                    <TextField
                                                        placeholder="Ask Anything"
                                                        size="small"
                                                        className="multilineInput"
                                                        value={inputs[checklist.checklist_id] || ""}
                                                        onChange={(e) => handleInputChange(e, checklist.checklist_id)}
                                                        fullWidth
                                                    // disabled={!!caseDetails?.leadId}
                                                    />
                                                    <Box
                                                        sx={{
                                                            display: "flex",
                                                            justifyContent: "flex-end",
                                                            gap: 1,
                                                            ".MuiButtonBase-root": {
                                                                border: "1px solid #EBEBEB",
                                                                backgroundColor: "#EBEBEB",
                                                                borderRadius: "6px",
                                                                color: "#00060A",
                                                                px: 3,
                                                            },
                                                        }}
                                                    >
                                                        <Button onClick={() => handleClear(checklist.checklist_id)}
                                                        // disabled={!!caseDetails?.leadId

                                                        // }
                                                        >Clear</Button>
                                                        <Button onClick={() => handleSubmit(checklist.checklist_id)}
                                                        // disabled={!!caseDetails?.leadId}
                                                        >
                                                            Ask Co-Pilot
                                                        </Button>
                                                    </Box>
                                                    <Typography className="typographyFontWeight">Answer</Typography>
                                                    <TextField
                                                        placeholder="Answer"
                                                        size="small"
                                                        className="multilineInput"
                                                        value={apiData[checklist.checklist_id] || ""}
                                                        slotProps={{
                                                            input: {
                                                                readOnly: true,
                                                            },
                                                        }}
                                                        fullWidth
                                                        multiline
                                                        rows={4}
                                                    // disabled={!!caseDetails?.leadId}
                                                    />
                                                    {apiData[checklist.checklist_id] && (
                                                        <Box
                                                            sx={{
                                                                textAlign: "right",
                                                                marginTop: "-10px",
                                                                padding: "8px 0",
                                                                position: "relative",
                                                                top: "0",
                                                                right: "14px",
                                                            }}
                                                        >
                                                            <Link
                                                                href="#"
                                                                onClick={(e) => {
                                                                    setDisplayNote(`note${checklist.checklist_id}`);
                                                                    handleAddToNotes(e, checklist);
                                                                }}
                                                                sx={{ color: "blue" }}
                                                            // disabled={!!caseDetails?.leadId}
                                                            >
                                                                Add to Notes
                                                            </Link>
                                                        </Box>
                                                    )}
                                                </Grid2>
                                            )}
                                            <Divider sx={{ my: 1, width: "100%" }} />
                                            <>
                                                {localStorage.getItem("userRole") === "INSPECTOR" && (
                                                    <Box display="flex" columnGap={3} mr={3}>
                                                        <Box className="attchmentsContainer">
                                                            <Button
                                                                component="label"
                                                                role={undefined}
                                                                tabIndex={-1}
                                                                sx={{
                                                                    fontWeight: 500,
                                                                    color: "black",
                                                                    fontSize: 14,
                                                                    height: "25px",
                                                                    pointerEvents: !!caseDetails?.leadId ? "none" : "auto",
                                                                }}
                                                                startIcon={<AttachFileIcon sx={{ fontSize: 12 }} />}
                                                            // disabled={!!caseDetails?.leadId}
                                                            >
                                                                <VisuallyHiddenInput
                                                                    type="file"
                                                                    accept="image/*"
                                                                    onChange={(e) => {
                                                                        attchImage(e, checklist);
                                                                    }}
                                                                />
                                                                Attach Image
                                                            </Button>
                                                        </Box>
                                                        <Box
                                                            className="attchmentsContainer"
                                                            onClick={() => setDisplayNote(`note${checklist.checklist_id}`)}
                                                            // onClick={() => {
                                                            //     if (!caseDetails?.leadId) {
                                                            //         setDisplayNote(`note${checklist.checklist_id}`);
                                                            //     }
                                                            // }}
                                                            // sx={{
                                                            //     pointerEvents: !!caseDetails?.leadId ? "none" : "auto",
                                                            //     opacity: !!caseDetails?.leadId ? '0.5 ! important' : '1',
                                                            // }}
                                                        >
                                                            <img src={AddNotes} alt="Add notes" />
                                                            <Typography ml={1} className="typographyFontWeight"
                                                                sx={{
                                                                    // color: !!caseDetails?.leadId ? "#B0B0B0" : "inherit" 
                                                                }}>
                                                                Add Notes
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                )}
                                                <Box
                                                    className="attchmentsContainer"
                                                    onClick={() => {
                                                        setIsEditCorrectiveAction(false);
                                                        setDisplayAddAction(`correctiveAction${checklist.checklist_id}`);
                                                    }}
                                                    // onClick={() => {
                                                    //     if (!caseDetails?.leadId) {
                                                    //         setIsEditCorrectiveAction(false);
                                                    //         setDisplayAddAction(`correctiveAction${checklist.checklist_id}`);
                                                    //     }
                                                    // }}
                                                    // sx={{
                                                    //     pointerEvents: !!caseDetails?.leadId ? "none" : "auto",
                                                    //     opacity: !!caseDetails?.leadId ? '0.5 !important' : '1',
                                                    // }}
                                                >
                                                    <AddActionsOutlinedIcon sx={{ mr: 1 }} />
                                                    <Typography className="typographyFontWeight">
                                                        Add Corrective Actions
                                                    </Typography>
                                                </Box>
                                                <Divider sx={{ my: 1, width: "100%" }} />
                                            </>
                                            {checklist?.attachments?.length > 0 && (
                                                <>
                                                    <Box>
                                                        <Typography className="headingFontWeight">Documents</Typography>
                                                        <Box className="attachmentContainer">
                                                            {checklist?.attachments?.map((attachment, index) => {
                                                                return (
                                                                    <Box className="attachmentItem" key={index}>
                                                                        <Box className="imageContainer">
                                                                            <img
                                                                                src={getImageThumbnail(attachment)}
                                                                                alt={attachment.name}
                                                                                className="attchmentImage"
                                                                            />
                                                                            <Typography className="attachmentTextStyle">
                                                                                {attachment.name?.length > 10
                                                                                    ? attachment.name?.slice(0, 9) + "..."
                                                                                    : attachment.name}
                                                                            </Typography>
                                                                        </Box>
                                                                        <Box className="imageDownload">
                                                                            <img src={DownloadImage} alt="Download" />
                                                                        </Box>
                                                                    </Box>
                                                                );
                                                            })}
                                                        </Box>
                                                    </Box>
                                                    <Divider sx={{ my: 1, width: "100%" }} />
                                                </>
                                            )}
                                            {(checklist?.comment || displayNote === `note${checklist.checklist_id}`) && (
                                                <>
                                                    <Box width="100%">
                                                        <Typography className="headingFontWeight">Note</Typography>
                                                        <TextField
                                                            size="small"
                                                            fullWidth
                                                            disabled={localStorage.getItem("userRole") !== "INSPECTOR"}
                                                            rows={2}
                                                            className="multilineInput"
                                                            multiline
                                                            value={checklist?.comment}
                                                            onChange={(e) => updateChecklistNote(e, checklist)}
                                                        />
                                                    </Box>
                                                    <Divider sx={{ my: 1, width: "100%" }} />
                                                </>
                                            )}
                                            {displayAddAction === `correctiveAction${checklist.checklist_id}` && (
                                                <>
                                                    <Box width="100%">
                                                        <Typography className="headingFontWeight">Corrective Actions</Typography>
                                                        <Box className="correctiveActionContainer">
                                                            <TextField
                                                                size="small"
                                                                fullWidth
                                                                className="correctiveActionField"
                                                                value={correctiveAction}
                                                                onChange={(e) => setCorrectiveAction(e.target.value)}
                                                            />
                                                        </Box>
                                                        <Box className="iconContainer">
                                                            <IconButton onClick={() => setDisplayAddAction("")}>
                                                                <CloseIcon sx={{ color: "#d54b4b", fontWeight: "bold" }} />
                                                            </IconButton>
                                                            <IconButton
                                                                onClick={() => {
                                                                    updateCorrectiveActions(checklist);
                                                                }}
                                                            >
                                                                <CheckIcon sx={{ color: "#03911a", fontWeight: "bold" }} />
                                                            </IconButton>
                                                        </Box>
                                                    </Box>
                                                    <Divider sx={{ mt: 1, mb: 3, width: "100%" }} />
                                                </>
                                            )}
                                            {checklist.selected_corrective_action?.filter((action) => action !== "")?.length >
                                                0 && (
                                                    <>
                                                        <Box width="100%">
                                                            <Typography className="headingFontWeight">Corrective Actions</Typography>
                                                            {checklist.selected_corrective_action?.map(
                                                                (action, index) =>
                                                                    action && (
                                                                        <Box key={index} className="correctiveActions">
                                                                            {isEditCorrectiveAction &&
                                                                                index === correctiveActionId ? (
                                                                                <Box
                                                                                    sx={{
                                                                                        display: "flex",
                                                                                        flexDirection: "column",
                                                                                        width: "100%",
                                                                                    }}
                                                                                >
                                                                                    <TextField
                                                                                        size="small"
                                                                                        fullWidth
                                                                                        className="correctiveActionField"
                                                                                        value={editedCorrectiveAction}
                                                                                        onChange={(e) =>
                                                                                            setEditedCorrectiveAction(e.target.value)
                                                                                        }
                                                                                    />
                                                                                    <Box className="iconContainer">
                                                                                        <IconButton
                                                                                            onClick={() =>
                                                                                                setIsEditCorrectiveAction(false)
                                                                                            }
                                                                                        >
                                                                                            <CloseIcon
                                                                                                sx={{
                                                                                                    color: "#d54b4b",
                                                                                                    fontWeight: "bold",
                                                                                                }}
                                                                                            />
                                                                                        </IconButton>
                                                                                        <IconButton
                                                                                            onClick={() => {
                                                                                                editCorrectiveAction(
                                                                                                    checklist,
                                                                                                    action
                                                                                                );
                                                                                            }}
                                                                                        >
                                                                                            <CheckIcon
                                                                                                sx={{
                                                                                                    color: "#03911a",
                                                                                                    fontWeight: "bold",
                                                                                                }}
                                                                                            />
                                                                                        </IconButton>
                                                                                    </Box>
                                                                                </Box>
                                                                            ) : (
                                                                                <>
                                                                                    <Typography className="typographyFontWeight">
                                                                                        {action}
                                                                                    </Typography>
                                                                                    <Box>
                                                                                        <IconButton
                                                                                            onClick={() => {
                                                                                                if (!isEditCorrectiveAction) {
                                                                                                    setCorrectiveActionId(index);
                                                                                                    setIsEditCorrectiveAction(true);
                                                                                                    setEditedCorrectiveAction(action);
                                                                                                }
                                                                                            }}
                                                                                        >
                                                                                            <EditOutlinedIcon
                                                                                                sx={{
                                                                                                    color: "#03911a",
                                                                                                    fontWeight: "bold",
                                                                                                }}
                                                                                            />
                                                                                        </IconButton>
                                                                                        <IconButton
                                                                                            onClick={() =>
                                                                                                deleteCorrectiveAction(
                                                                                                    checklist,
                                                                                                    action
                                                                                                )
                                                                                            }
                                                                                        >
                                                                                            <DeleteOutlinedIcon
                                                                                                sx={{
                                                                                                    color: "#d54b4b",
                                                                                                    fontWeight: "bold",
                                                                                                }}
                                                                                            />
                                                                                        </IconButton>
                                                                                    </Box>
                                                                                </>
                                                                            )}
                                                                        </Box>
                                                                    )
                                                            )}
                                                        </Box>
                                                        <Divider sx={{ mt: 1, mb: 3, width: "100%" }} />
                                                    </>
                                                )}
                                        </>
                                    );
                                })}
                            </Grid2>

                            {(localStorage.getItem("userRole") === "REVIEWER" ||
                                localStorage.getItem("userRole") === "APPROVER") && (
                                    <Grid2 container size={12} sx={{ mt: 2 }}>
                                        <Typography className="headingFontWeight" variant="h5">
                                            Reviewer's Comments
                                        </Typography>
                                        <TextField
                                            size="small"
                                            fullWidth
                                            rows={3}
                                            disabled={localStorage.getItem("userRole") === "APPROVER"}
                                            className="multilineInput"
                                            multiline
                                            value={reviwerCategoryReport}
                                            onChange={(e) => setReviwerCategoryReport(e.target.value)}
                                        />
                                    </Grid2>
                                )}
                            {localStorage.getItem("userRole") === "APPROVER" && (
                                <Grid2 container size={12} sx={{ mt: 2 }}>
                                    <Typography className="headingFontWeight" variant="h5">
                                        Approver's Report
                                    </Typography>
                                    <TextField
                                        size="small"
                                        fullWidth
                                        rows={3}
                                        className="multilineInput"
                                        multiline
                                        value={approverCategoryReport}
                                        onChange={(e) => setApproverCategoryReport(e.target.value)}
                                    />
                                </Grid2>
                            )}
                        </>
                    )}
                    {showInspectionReport && (
                        <Grid2 size={12} container direction="column">
                            <Typography className="headingFontWeight" variant="h5">
                                Inspection Report
                            </Typography>
                            <TextField
                                size="small"
                                fullWidth
                                disabled={localStorage.getItem("userRole") !== "INSPECTOR"}
                                rows={3}
                                className="multilineInput"
                                multiline
                                value={inspectionReport}
                                onChange={(e) => setInspectionReport(e.target.value)}
                            />
                        </Grid2>
                    )}
                    {showRecommendedActions && localStorage.getItem("userRole") === "APPROVER" && (
                        <Grid2 container size={12} direction={"column"} className="recommendedActionsContainer">
                            <Typography className="headingFontWeight" variant="h5">
                                Recommended Actions
                            </Typography>
                            <Grid2 container size={12}>
                                <RadioGroup
                                    aria-labelledby="demo-radio-buttons-group-label"
                                    defaultValue="female"
                                    name="radio-buttons-group"
                                    value={recommendedAction}
                                    onChange={(e) => setRecommendedAction(e.target.value)}
                                    sx={{
                                        width: "100%",
                                    }}
                                >
                                    <Box
                                        sx={{
                                            border: recommendedAction === "No Action" ? `2px solid #4C8B92` : `1px solid #CCCCCC`,
                                            borderRadius: "6px",
                                            opacity: 1,
                                            px: 2,
                                            py: 1,
                                            mb: 2,
                                        }}
                                    >
                                        <FormControlLabel
                                            value="No Action"
                                            control={<CustomRadio sx={{ mr: 1 }} />}
                                            label={
                                                <>
                                                    <Typography
                                                        variant="h6"
                                                        color={recommendedAction === "No Action" ? "#4C8B92" : "#00060A"}
                                                    >
                                                        No Action Required
                                                    </Typography>
                                                    <Typography fontSize="12px" color="#6A6969">
                                                        No action required, Inspection has been completed successfully.
                                                    </Typography>
                                                </>
                                            }
                                        />
                                    </Box>
                                    <Box
                                        sx={{
                                            border: recommendedAction === "Follow Up" ? `2px solid #4C8B92` : `1px solid #CCCCCC`,
                                            borderRadius: "6px",
                                            opacity: 1,
                                            px: 2,
                                            py: 1,
                                            mb: 2,
                                        }}
                                    >
                                        <FormControlLabel
                                            value="Follow Up"
                                            control={<CustomRadio sx={{ mr: 1 }} />}
                                            label={
                                                <>
                                                    <Typography
                                                        variant="h6"
                                                        color={recommendedAction === "Follow Up" ? "#4C8B92" : "#00060A"}
                                                    >
                                                        Follow Up Required
                                                    </Typography>
                                                    <Typography fontSize="12px" color="#6A6969">
                                                        Follow up required, please select a date for follow up and complete the
                                                        case.
                                                    </Typography>
                                                </>
                                            }
                                        />
                                    </Box>
                                    <Box
                                        sx={{
                                            border:
                                                recommendedAction === "Re-Inspection" ? `2px solid #4C8B92` : `1px solid #CCCCCC`,
                                            borderRadius: "6px",
                                            opacity: 1,
                                            px: 2,
                                            py: 1,
                                        }}
                                    >
                                        <FormControlLabel
                                            value="Re-Inspection"
                                            control={<CustomRadio sx={{ mr: 1 }} />}
                                            label={
                                                <>
                                                    <Typography
                                                        variant="h6"
                                                        color={recommendedAction === "Re-Inspection" ? "#4C8B92" : "#00060A"}
                                                    >
                                                        Re-Inspection Required
                                                    </Typography>
                                                    <Typography fontSize="12px" color="#6A6969">
                                                        Re-Inspection required, please select a date for re-inspection and
                                                        complete the case.
                                                    </Typography>
                                                </>
                                            }
                                        />
                                    </Box>
                                </RadioGroup>
                            </Grid2>
                            {(recommendedAction === "Follow Up" || recommendedAction === "Re-Inspection") && (
                                <Grid2 container size={12} spacing={0} direction={"column"} sx={{ mb: 1 }}>
                                    <Typography variant="h6">
                                        {recommendedAction === "Follow Up" ? "Follow Up Date" : "Re Inspection Date"}
                                    </Typography>

                                    <LocalizationProvider
                                        dateAdapter={AdapterDayjs}
                                        localeText={{
                                            fieldDayPlaceholder: () => "DD",
                                            fieldMonthPlaceholder: () => "MMM",
                                            fieldYearPlaceholder: () => "YYYY",
                                        }}
                                    >
                                        <DatePicker
                                            size="small"
                                            value={inspectionDate}
                                            onChange={(value) =>
                                                recommendedAction === "Follow Up"
                                                    ? setFollowUpDate(dayjs(value).format("YYYY-MM-DD"))
                                                    : recommendedAction === "Re-Inspection"
                                                        ? setReInspectionDate(dayjs(value).format("YYYY-MM-DD"))
                                                        : ""
                                            }
                                            format="DD MMM YYYY"
                                            className="dateField"
                                            sx={{ height: "40px", width: "370px" }}
                                            required
                                        />
                                    </LocalizationProvider>
                                </Grid2>
                            )}
                            {recommendedAction && (
                                <>
                                    <Grid2 container size={12} sx={{ marginBottom: "10px" }}>
                                        <Typography className="headingFontWeight" variant="h5">
                                            Inspection Summary Report
                                        </Typography>
                                        <TextField
                                            size="small"
                                            fullWidth
                                            rows={3}
                                            className="multilineInput"
                                            multiline
                                            value={inspectionSummaryReport}
                                            onChange={(e) => setInspectionSummaryReport(e.target.value)}
                                        />
                                    </Grid2>
                                </>
                            )}
                        </Grid2>
                    )}
                    {showRecommendedActions && localStorage.getItem("userRole") === "REVIEWER" && (
                        <Grid2 container size={12} direction={"column"} className="recommendedActionsContainer">
                            <Typography className="headingFontWeight" variant="h5">
                                Recommended Actions
                            </Typography>
                            <Grid2 container size={12}>
                                <RadioGroup
                                    aria-labelledby="demo-radio-buttons-group-label"
                                    defaultValue="female"
                                    name="radio-buttons-group"
                                    value={recommendedAction}
                                    onChange={(e) => setRecommendedAction(e.target.value)}
                                    sx={{
                                        width: "100%",
                                    }}
                                >
                                    <Box
                                        sx={{
                                            border: recommendedAction === "Pass" ? `2px solid #4C8B92` : `1px solid #CCCCCC`,
                                            borderRadius: "6px",
                                            opacity: 1,
                                            px: 2,
                                            py: 1,
                                            mb: 2,
                                        }}
                                    >
                                        <FormControlLabel
                                            value="Pass"
                                            control={<CustomRadio sx={{ mr: 1 }} />}
                                            label={
                                                <>
                                                    <Typography
                                                        variant="h6"
                                                        color={recommendedAction === "Pass" ? "#4C8B92" : "#00060A"}
                                                    >
                                                        Pass
                                                    </Typography>
                                                    <Typography fontSize="12px" color="#6A6969">
                                                        Passed at reviewer stage and will be sent to Approver
                                                    </Typography>
                                                </>
                                            }
                                        />
                                    </Box>
                                    <Box
                                        sx={{
                                            border:
                                                recommendedAction === "Fail" ||
                                                    recommendedAction === "Redo" ||
                                                    recommendedAction === "Re-Inspection"
                                                    ? `2px solid #4C8B92`
                                                    : `1px solid #CCCCCC`,
                                            borderRadius: "6px",
                                            opacity: 1,
                                            px: 2,
                                            py: 1,
                                            mb: 2,
                                        }}
                                    >
                                        <FormControlLabel
                                            value="Fail"
                                            control={<CustomRadio sx={{ mr: 1 }} />}
                                            label={
                                                <>
                                                    <Typography
                                                        variant="h6"
                                                        color={recommendedAction === "Fail" ? "#4C8B92" : "#00060A"}
                                                    >
                                                        Fail
                                                    </Typography>
                                                    <Typography fontSize="12px" color="#6A6969">
                                                        Please select the next step from following and complete the case
                                                    </Typography>
                                                </>
                                            }
                                        />

                                        {(recommendedAction === "Fail" ||
                                            recommendedAction === "Redo" ||
                                            recommendedAction === "Re-Inspection") && (
                                                <>
                                                    <Box
                                                        sx={{
                                                            border:
                                                                recommendedAction === "Redo"
                                                                    ? `2px solid #4C8B92`
                                                                    : `1px solid #CCCCCC`,
                                                            borderRadius: "6px",
                                                            opacity: 1,
                                                            px: 2,
                                                            py: 1,
                                                            mb: 2,
                                                            mt: 3,
                                                            mx: 2,
                                                        }}
                                                    >
                                                        <FormControlLabel
                                                            value="Redo"
                                                            control={<CustomRadio sx={{ mr: 1 }} />}
                                                            label={
                                                                <>
                                                                    <Typography
                                                                        variant="h6"
                                                                        color={recommendedAction === "Redo" ? "#4C8B92" : "#00060A"}
                                                                    >
                                                                        Redo
                                                                    </Typography>
                                                                    <Typography fontSize="12px" color="#6A6969">
                                                                        Please select checklist items needed for redo and send the
                                                                        case back to inspector{" "}
                                                                    </Typography>
                                                                </>
                                                            }
                                                        />
                                                    </Box>
                                                    <Box
                                                        sx={{
                                                            border:
                                                                recommendedAction === "Re-Inspection"
                                                                    ? `2px solid #4C8B92`
                                                                    : `1px solid #CCCCCC`,
                                                            borderRadius: "6px",
                                                            opacity: 1,
                                                            px: 2,
                                                            py: 1,
                                                            mb: 2,
                                                            mx: 2,
                                                        }}
                                                    >
                                                        <FormControlLabel
                                                            value="Re-Inspection"
                                                            control={<CustomRadio sx={{ mr: 1 }} />}
                                                            label={
                                                                <>
                                                                    <Typography
                                                                        variant="h6"
                                                                        color={
                                                                            recommendedAction === "Re-Inspection"
                                                                                ? "#4C8B92"
                                                                                : "#00060A"
                                                                        }
                                                                    >
                                                                        Re-Inspection Required
                                                                    </Typography>
                                                                    <Typography fontSize="12px" color="#6A6969">
                                                                        Re-Inspection required,please select a date for re-inspection
                                                                        and complete the case{" "}
                                                                    </Typography>
                                                                </>
                                                            }
                                                        />
                                                    </Box>
                                                </>
                                            )}
                                    </Box>
                                </RadioGroup>
                            </Grid2>
                            {recommendedAction === "Re-Inspection" && (
                                <Grid2 container size={12} direction={"column"} sx={{ mb: 3 }}>
                                    <Typography variant="h6" className="headingFontWeight">
                                        Re Inspection Required{" "}
                                    </Typography>
                                    <LocalizationProvider
                                        dateAdapter={AdapterDayjs}
                                        localeText={{
                                            fieldDayPlaceholder: () => "Choose date",
                                            fieldMonthPlaceholder: () => "",
                                            fieldYearPlaceholder: () => "",
                                        }}
                                    >
                                        <DatePicker
                                            size="small"
                                            value={inspectionDate}
                                            onChange={(value) => setReInspectionDate(dayjs(value).format("YYYY-MM-DD"))}
                                            //renderInput={(params) => <TextField {...params} placeholder="Choose date" />}
                                            format="DD MMM YYYY"
                                            className="dateField"
                                            sx={{ height: "40px", width: "370px" }}
                                            required
                                        />
                                    </LocalizationProvider>
                                </Grid2>
                            )}
                            {recommendedAction === "Redo" && (
                                <Button
                                    sx={{
                                        border: "2px dashed #CCCCCC",
                                        borderRadius: "6px",
                                        padding: "16px",
                                        display: "flex",
                                        justifyContent: "space-between",
                                        alignItems: "center",
                                        backgroundColor: "#F8F9FA",
                                        width: "100%",
                                        textAlign: "left",
                                        textTransform: "none",
                                        mb: 2,
                                    }}
                                    onClick={handleGoBackFromRedo}
                                >
                                    <Box sx={{ display: "flex", gap: "15px" }}>
                                        <Box>
                                            <AddIcon fontSize="large" sx={{ color: "grey" }} />
                                        </Box>
                                        <Box>
                                            <Typography
                                                variant="h6"
                                                sx={{
                                                    fontSize: "14px",
                                                    color: "#6A6969",
                                                }}
                                            >
                                                Select Checklist for Redo
                                            </Typography>
                                            <Typography sx={{ fontSize: "12px", color: "#6A6969" }}>
                                                Checklist selected will be marked for "Redo" when Inspector reopens the case
                                            </Typography>
                                        </Box>
                                    </Box>
                                    <Box
                                        sx={{
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "center",
                                            borderRadius: "4px",
                                            backgroundColor: "#E1F5F8",
                                            padding: "4px 16px",
                                            fontSize: "16px",
                                            color: "#4C8B92",
                                        }}
                                    >
                                        4/24 Selected
                                    </Box>
                                </Button>
                            )}
                            {(recommendedAction === "Pass" ||
                                recommendedAction === "Redo" ||
                                recommendedAction === "Re-Inspection") && (
                                    <>
                                        <Grid2 container size={12} sx={{ marginBottom: "10px" }}>
                                            <Typography className="headingFontWeight" variant="h5">
                                                Inspection Summary Report
                                            </Typography>
                                            <TextField
                                                size="small"
                                                fullWidth
                                                rows={3}
                                                className="multilineInput"
                                                multiline
                                                value={inspectionSummaryReport}
                                                onChange={(e) => setInspectionSummaryReport(e.target.value)}
                                            />
                                        </Grid2>
                                    </>
                                )}
                        </Grid2>
                    )}
                    <Grid2 container size={12} columnGap={3} sx={{ justifyContent: "flex-end" }}>
                        <Button
                            variant="outlined"
                            className="saveButton"
                            onClick={() => {
                                if (localStorage.getItem("userRole") === "INSPECTOR") {
                                    if (action === "assign") {
                                        assignCategoriesToInspectors("save");
                                    } else {
                                        saveInspection();
                                    }
                                }
                                if (localStorage.getItem("userRole") === "APPROVER") {
                                    saveSubmitReviewerApproval("save", recommendedAction, followUpDate, ReInspectionDate);
                                }
                                if (localStorage.getItem("userRole") === "REVIEWER") {
                                    saveSubmitReviewerApproval("save", recommendedAction, followUpDate, ReInspectionDate);
                                }
                            }}
                        >
                            Save
                        </Button>
                        {((localStorage.getItem("userRole") === "INSPECTOR" && !showInspectionReport) ||
                            (localStorage.getItem("userRole") === "APPROVER" && !showRecommendedActions) ||
                            (localStorage.getItem("userRole") === "REVIEWER" && !showRecommendedActions)) && (
                                // <Button
                                //     className="nextSubmitButton"
                                //     disabled={action === "assign" && currentChecklistId.current === inspectionChecklist?.length - 1}
                                //     onClick={() => {
                                //         if (currentChecklistId.current < inspectionChecklist?.length - 1) {
                                //             if (showInspectionReport) {
                                //                 currentChecklistId.current = 0;
                                //             } else {
                                //                 currentChecklistId.current = currentChecklistId.current + 1;
                                //             }
                                //             updateInspectionChecklist();
                                //         } else {
                                //             if (localStorage.getItem("userRole") === "INSPECTOR") {
                                //                 displayInspectionReport();
                                //             } else if (localStorage.getItem("userRole") === "APPROVER") {
                                //                 displayRecommendedActions();
                                //             } else if (localStorage.getItem("userRole") === "REVIEWER") {
                                //                 displayRecommendedActions();
                                //             }
                                //         }
                                //     }}
                                // >
                                //     Next
                                // </Button>
                                <Button
                                    className="nextSubmitButton"
                                    // disabled={action === "assign" && currentChecklistId.current === inspectionChecklist?.length - 1}
                                    onClick={() => {
                                        if (currentChecklistId.current < inspectionChecklist?.length - 1) {
                                            if (showInspectionReport) {
                                                currentChecklistId.current = 0;
                                            } else {
                                                currentChecklistId.current = currentChecklistId.current + 1;
                                            }
                                            updateInspectionChecklist();
                                        } else {
                                            if (localStorage.getItem("userRole") === "INSPECTOR") {
                                                if (action === "assign") {
                                                    assignCategoriesToInspectors("submit");
                                                } else {
                                                    displayInspectionReport();
                                                }
                                            } else if (localStorage.getItem("userRole") === "APPROVER") {
                                                displayRecommendedActions();
                                            } else if (localStorage.getItem("userRole") === "REVIEWER") {
                                                displayRecommendedActions();
                                            }
                                        }
                                    }}
                                >
                                    {/* Next */}
                                    {localStorage.getItem("userRole") === "INSPECTOR" && action === "assign" ? "Submit" : "Next"}
                                </Button>

                            )}
                        {((localStorage.getItem("userRole") === "INSPECTOR" && showInspectionReport) ||
                            (localStorage.getItem("userRole") === "APPROVER" && showRecommendedActions) ||
                            (localStorage.getItem("userRole") === "REVIEWER" && showRecommendedActions)) && (
                                <Button
                                    className="nextSubmitButton"
                                    onClick={() => {
                                        if (localStorage.getItem("userRole") === "INSPECTOR") {
                                            if (caseDetails?.caseCreationType === "individual") {
                                                submitInspection();
                                            } else if (
                                                action === "review" &&
                                                (caseDetails?.caseCreationType === "group" ||
                                                    caseDetails?.caseCreationType === "plan") &&
                                                caseDetails?.leadId === parseInt(localStorage.getItem("userID"))
                                            ) {
                                                submitInspection();
                                            } else {
                                                saveInspection();
                                            }
                                        }
                                        if (localStorage.getItem("userRole") === "APPROVER") {
                                            saveSubmitReviewerApproval("submit", recommendedAction, followUpDate, ReInspectionDate);
                                        }
                                        if (localStorage.getItem("userRole") === "REVIEWER") {
                                            saveSubmitReviewerApproval("submit", recommendedAction, followUpDate, ReInspectionDate);
                                        }
                                    }}
                                    sx={{
                                        backgroundColor:
                                            localStorage.getItem("userRole") === "REVIEWER" && !recommendedAction
                                                ? "grey !important"
                                                : "",
                                        color:
                                            localStorage.getItem("userRole") === "REVIEWER" && !recommendedAction
                                                ? "white !important"
                                                : "",
                                    }}
                                    disabled={localStorage.getItem("userRole") === "REVIEWER" && !recommendedAction}
                                >
                                    Submit
                                </Button>


                            )}
                    </Grid2>
                </Grid2>
            </Grid2>
        </>
    );
};

export default Checklist;