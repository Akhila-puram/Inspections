import React, { useState } from "react";
import { Typography, Grid2, Link, useTheme, Drawer } from "@mui/material";
import "./caseDetails.css";
import CaseDetails from "./CaseDetails";

const Header = ({ caseDetails }) => {
    const theme = useTheme();
    const [openDrawer, setOpenDrawer] = useState(false);

    const caseInfo = {
        inspectionId: "123456",
        name: "Mc Donalds",
        owenName: "Andrew",
        contactNumer: "9876789234",
        inspection_source: "adhoc",
        referenceCase: "123.5",
    };

    return (
        <Grid2 container className="headerContainer">
            <Grid2 size={1.5}>
                <Typography className="contentHeading">Case ID:</Typography>
                <Typography className="contentBody">{caseDetails?.inspectionID ? caseDetails?.inspectionID : "-"}</Typography>
            </Grid2>
            <Grid2 size={1.5}>
                <Typography className="contentHeading">Entity Name:</Typography>
                <Typography className="contentBody">
                    {caseDetails?.name
                        ? caseDetails?.name?.length > 12
                            ? caseDetails?.name?.slice(0, 12) + "..."
                            : caseDetails?.name
                        : "-"}
                </Typography>
            </Grid2>
            <Grid2 item xs={2}>
                <Typography className="contentHeading">Representative Name:</Typography>
                <Typography className="contentBody">
                    {caseDetails?.representative_name ? caseDetails?.representative_name : "-"}
                </Typography>
            </Grid2>
            <Grid2 size={1.7}>
                <Typography className="contentHeading">Contact Number:</Typography>
                <Typography className="contentBody">
                    {caseDetails?.representative_phoneno ? caseDetails?.representative_phoneno : "-"}
                </Typography>
            </Grid2>
            <Grid2 size={1.5}>
                <Typography className="contentHeading">Inspection Source:</Typography>
                <Typography className="contentBody">
                    {caseDetails?.inspector_source ? caseDetails?.inspector_source : "-"}
                </Typography>
            </Grid2>
            <Grid2 size={1.3}>
                <Typography className="contentHeading">Reference Case:</Typography>
                <Link href="#" className="linkStyle">
                    {caseDetails?.reference_case ? caseDetails?.reference_case : "-"}
                </Link>
            </Grid2>
            <Grid2 size={1}>
                <Link className="linkStyle" onClick={() => setOpenDrawer(true)}>
                    More Details
                </Link>
            </Grid2>
            <Drawer
                open={openDrawer}
                onClose={() => setOpenDrawer(false)}
                anchor="right"
                sx={{
                    backdropFilter: blur("50px"),
                }}
            >
                <CaseDetails setOpenDrawer={setOpenDrawer} caseDetails={caseDetails} />
            </Drawer>
        </Grid2>
    );
};

export default Header;
