import React from "react";

const GroupReports = () => {
    return <div>Group Reports</div>;
};

export default GroupReports;
